#!/usr/bin/bash
RUN_DFU_FILE="run_update"

cd /etc/cron.daily/
if [ -e $RUN_DFU_FILE ]; then
	sudo rm -f /etc/cron.daily/$RUN_DFU_FILE
fi
