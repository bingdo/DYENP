from model import *

from ocpp.v16.configuration import *
from ocpp.v16.constants import ConfigurationStatus


class ConfigurationClass:
    def __init__(self):
        self.conf = {}
        self.model = Configuration
        self.getConfigurationAll()

    def valueValidator(self, key, value):
        try:
            data = {"value": value}
            try:
                KeyList[key]
            except KeyError:
                return ConfigurationStatus.NotSupported.name

            if key == KeyList.AllowOfflineTxForUnkownId.name:
                AllowOfflineTxForUnkownId(**data)
            if key == KeyList.AuthorizationCacheEnabled.name:
                AuthorizationCacheEnabled(**data)
            if key == KeyList.AuthorizeRemoteTxRequests.name:
                AuthorizeRemoteTxRequests(**data)
            if key == KeyList.BlinkRepeat.name:
                BlinkRepeat(**data)
            if key == KeyList.ClockAlignedDataInterval.name:
                ClockAlignedDataInterval(**data)
            if key == KeyList.ConnectionTimeOut.name:
                ConnectionTimeOut(**data)
            if key == KeyList.GetConfigurationMaxKeys.name:
                GetConfigurationMaxKeys(**data)
            if key == KeyList.HeartbeatInterval.name:
                HeartbeatInterval(**data)
            if key == KeyList.LightIntensity.name:
                LightIntensity(**data)
            if key == KeyList.LocalAuthorizeOffline.name:
                LocalAuthorizeOffline(**data)
            if key == KeyList.LocalPreAuthorize.name:
                LocalPreAuthorize(**data)
            if key == KeyList.MaxEnergyOnInvalidId.name:
                MaxEnergyOnInvalidId(**data)
            if key == KeyList.MeterValuesAlignedData.name:
                MeterValuesAlignedData(**data)
            if key == KeyList.MeterValuesAlignedDataMaxLength.name:
                MeterValuesAlignedDataMaxLength(**data)
            if key == KeyList.MeterValuesSampledData.name:
                MeterValuesSampledData(**data)
            if key == KeyList.MeterValuesSampledDataMaxLength.name:
                MeterValuesSampledDataMaxLength(**data)
            if key == KeyList.MeterValueSampleInterval.name:
                MeterValueSampleInterval(**data)
            if key == KeyList.MinimumStatusDuration.name:
                MinimumStatusDuration(**data)
            if key == KeyList.NumberOfConnectors.name:
                NumberOfConnectors(**data)
            if key == KeyList.ResetRetries.name:
                ResetRetries(**data)
            if key == KeyList.ConnectorPhaseRotation.name:
                ConnectorPhaseRotation(**data)
            if key == KeyList.ConnectorPhaseRotationMaxLength.name:
                ConnectorPhaseRotationMaxLength(**data)
            if key == KeyList.StopTransactionOnEVSideDisconnect.name:
                StopTransactionOnEVSideDisconnect(**data)
            if key == KeyList.StopTransactionOnInvalidId.name:
                StopTransactionOnInvalidId(**data)
            if key == KeyList.StopTxnAlignedData.name:
                StopTxnAlignedData(**data)
            if key == KeyList.StopTxnAlignedDataMaxLength.name:
                StopTxnAlignedDataMaxLength(**data)
            if key == KeyList.StopTxnSampledData.name:
                StopTxnSampledData(**data)
            if key == KeyList.StopTxnSampledDataMaxLength.name:
                StopTxnSampledDataMaxLength(**data)
            if key == KeyList.SupportedFeatureProfiles.name:
                SupportedFeatureProfiles(**data)
            if key == KeyList.SupportedFeatureProfilesMaxLength.name:
                SupportedFeatureProfilesMaxLength(**data)
            if key == KeyList.TransactionMessageAttempts.name:
                TransactionMessageAttempts(**data)
            if key == KeyList.TransactionMessageRetryInterval.name:
                TransactionMessageRetryInterval(**data)
            if key == KeyList.UnlockConnectorOnEVSideDisconnect.name:
                UnlockConnectorOnEVSideDisconnect(**data)
            if key == KeyList.WebSocketPingInterval.name:
                WebSocketPingInterval(**data)

            return ConfigurationStatus.Accepted.name
        except Exception as e:
            print(e)
            return ConfigurationStatus.Rejected.name

    def configurationInitialize(self):
        bulkInsertData = []

        allowOfflineTxForUnkownId = self.model(
            required=False,
            write_accessibility=True,
            key="AllowOfflineTxForUnkownId",
            value=False,
            description="Boolean"
        )  # 이 키가 존재하면 충전 포인트는 불명확한 오프라인 승인을 지원한다. 만약 이키가 'true'값을 보고한다면 불명확한 오프라인 권한 부여가 사용된다.
        bulkInsertData.append(allowOfflineTxForUnkownId)

        authorizationCacheEnabled = self.model(
            required=False,
            write_accessibility=True,
            key="AuthorizationCacheEnabled",
            value=False,
            description="Boolean"
        )  # 이 키가 존재하면 충전 포인트는 승인캐시를 지원한다. 만약 이 키가 ‘true‘값을 보고한다면 승인캐시가 사용된다
        bulkInsertData.append(authorizationCacheEnabled)

        authorizeRemoteTxRequests = self.model(
            required=True,
            write_accessibility=True,
            key="AuthorizeRemoteTxRequests",
            value=False,
            description="Boolean"
        )  # RemoteStartTransaction.req 메시지의 형태로, 트랜잭션을 시작하라는 원격 요청 이 트랜잭션을 시작하기 위한 현장 액션과 같이 미리 승인되어야 하는지에 대한 여부
        bulkInsertData.append(authorizeRemoteTxRequests)

        blinkRepeat = self.model(
            required=False,
            write_accessibility=True,
            key="BlinkRepeat",
            value=0,
            description="int(time) - 분 단위 일것으로 판단"
        )  # 신호 전송 시 점등 횟수
        bulkInsertData.append(blinkRepeat)

        clockAlignedDataInterval = self.model(
            required=True,
            write_accessibility=True,
            key="ClockAlignedDataInterval",
            value=0,
            description="int(seconds)"
        )
        # 클록 정렬 데이터 간격의 크기.
        # 00:00:00 (자정)부터 시작하여 일정 간격으로 집계 된 간격의 크기.
        # 클록 정렬 데이터가 전송 될 때 해당 간격은 ISO 8601 표준에 의거,
        # 표시되는 시 작시간 및 지속간격 값으로 식별된다.
        # 모든 구간 별 데이터는 전체 간격에 걸쳐 누적되거나 평균화 되어야 한다.
        # “0”의 값은 클록 정렬 데이터가 전송되지 않아야한다는 의미로 해석되어야 한다.
        bulkInsertData.append(clockAlignedDataInterval)

        connectionTimeOut = self.model(
            required=True,
            write_accessibility=True,
            key="ConnectionTimeOut",
            value=30,
            description="int(seconds)"
        )  # EV 사용자가 충전 케이블 커넥터를 적합한 커넥터에 삽입하지 못해 세션이 취소 될 때까지의 간격
        bulkInsertData.append(connectionTimeOut)

        getConfigurationMaxKeys = self.model(
            required=True,
            write_accessibility=False,
            key="GetConfigurationMaxKeys",
            value=1,
            description="int"
        )  # 요청된 구성 설정키의 최대 수. Getself.model.req PDU
        bulkInsertData.append(getConfigurationMaxKeys)

        heartbeatInterval = self.model(
            required=True,
            write_accessibility=True,
            key="HeartbeatInterval",
            value=3000,
            description="int(seconds)"
        )  # 충전 포인트가 중앙시스템으로 Heartbeat.req PDU를 보낸 후 비 활동 간격
        bulkInsertData.append(heartbeatInterval)

        lightIntensity = self.model(
            required=False,
            write_accessibility=True,
            key="LightIntensity",
            value=100,
            description="int(%)"
        )  # 충전 포인트 조명 밝기 최대 강도의 백분율
        bulkInsertData.append(lightIntensity)

        localAuthorizeOffline = self.model(
            required=True,
            write_accessibility=True,
            key="LocalAuthorizeOffline",
            value=False,
            description="Boolean"
        )  # 오프라인 상태인 충전 포인트가 자체 권한 부여된 식별자에 대한 트랜잭션을 시작할 것인지에 대한 여부
        bulkInsertData.append(localAuthorizeOffline)

        localPreAuthorize = self.model(
            required=True,
            write_accessibility=True,
            key="LocalPreAuthorize",
            value=False,
            description="Boolean"
        )  # 중앙시스템에서 Authorize.conf를 기다리거나 요청 하지 않고 자체 승인된 식별자에 대한 트랜잭션 시작 여부
        bulkInsertData.append(localPreAuthorize)

        maxEnergyOnInvalidId = self.model(
            required=False,
            write_accessibility=True,
            key="MaxEnergyOnInvalidId",
            value=0,
            description="int(Wh)"
        )  # 트랜잭션 시작 후 식별자가 중앙시스템에 의해 무효화되었을 때의 Wh 단위의 최대 에너지
        bulkInsertData.append(maxEnergyOnInvalidId)

        meterValuesAlignedData = self.model(
            required=False,
            write_accessibility=True,
            key="MeterValuesAlignedData",
            value="CSL",
            description="CSL"
        )  # MeterValues.req PDU에 포함될 클록 정렬 측정량
        bulkInsertData.append(meterValuesAlignedData)

        meterValuesAlignedDataMaxLength = self.model(
            required=False,
            write_accessibility=False,
            key="MeterValuesAlignedDataMaxLength",
            value=0,
            description="int"
        )  # MeterValuesAlignedData 설정키의 최대 항목 수
        bulkInsertData.append(meterValuesAlignedDataMaxLength)

        meterValuesSampledData = self.model(
            required=True,
            write_accessibility=True,
            key="MeterValuesSampledData",
            value="CSL",
            description="CSL"
        )  # 모든 MeterValuesSampleInterval 초마다 MeterValues.req PDU에 포함될 샘플링 된 측정항목
        bulkInsertData.append(meterValuesSampledData)

        meterValuesSampledDataMaxLength = self.model(
            required=False,
            write_accessibility=False,
            key="MeterValuesSampledDataMaxLength",
            value=0,
            description="int"
        )  # MeterValuesSampledData 설정키의 최대 항목수
        bulkInsertData.append(meterValuesSampledDataMaxLength)

        meterValueSampleInterval = self.model(
            required=True,
            write_accessibility=True,
            key="MeterValueSampleInterval",
            value=1,
            description="int(sec)"
        )  # 서버 에서 1초에 한번씩 보내달라는 요청
        # MeterValues PDU에 의해 전송되도록 의도된 미터링 데이터 샘플링 사이의 간격.
        # “0”의 값은 표본화 된 데이터가 전송되어서는 안됨을 의미하는 것으로 해석되어야 한다.
        bulkInsertData.append(meterValueSampleInterval)

        minimumStatusDuration = self.model(
            required=False,
            write_accessibility=True,
            key="MinimumStatusDuration",
            value=1,
            description="int(sec)"
        )  # StatusNotification.req PDU가 중앙시스템으로 전송되기 전 충전 포인트 또는 커넥터 상태가 안정된 최소 지속 시간.
        bulkInsertData.append(minimumStatusDuration)

        numberOfConnectors = self.model(
            required=True,
            write_accessibility=False,
            key="NumberOfConnectors",
            value=1,
            description="int"
        )  # 충전 포인트의 물리적 충전 커넥터의 수
        bulkInsertData.append(numberOfConnectors)

        resetRetries = self.model(
            required=True,
            write_accessibility=True,
            key="ResetRetries",
            value=1,
            description="int(time) -min 인거로 추정"
        )  # 충전 포인트의 재설정 실패 횟수
        bulkInsertData.append(resetRetries)

        connectorPhaseRotation = self.model(
            required=True,
            write_accessibility=True,
            key="ConnectorPhaseRotation",
            value="CSL",
            description="CSL"
        )
        # 커넥터의 에너지 계량기에 대한 커넥터 당 위상 회전.
        # NotApplicable (단상 또는 DC 충전 장치용)
        # Unknown (아직 알 수 없음)
        # RST (표준 기준 위상 조정)
        # RTS (역 참조 위상)
        # SRT (반전 된 240도 회전)
        # STR (표준 120도 회전)
        # TRS (표준 240도 회전)
        # TSR (120도 회전 반전)
        # R은 위상 1(L1), S는 위상 2(L2), T는 위상 3(L3)으로 식별 될 수 있다.
        # 값은 CSL 형식으로 보고된다.
        bulkInsertData.append(connectorPhaseRotation)

        connectorPhaseRotationMaxLength = self.model(
            required=False,
            write_accessibility=False,
            key="ConnectorPhaseRotationMaxLength",
            value=0,
            description="int"
        )  # ConnectorPhaseRotation 설정키의 최대 항목 수
        bulkInsertData.append(connectorPhaseRotationMaxLength)

        stopTransactionOnEVSideDisconnect = self.model(
            required=True,
            write_accessibility=True,
            key="StopTransactionOnEVSideDisconnect",
            value=True,
            description="Boolean"
        )  # ‘true’로 설정되면, 충전 포인트는 케이블이 EV로부터 분리되고 트랜잭션을 중단한다.
        bulkInsertData.append(stopTransactionOnEVSideDisconnect)

        stopTransactionOnInvalidId = self.model(
            required=True,
            write_accessibility=True,
            key="StopTransactionOnInvalidId",
            value=True,
            description="Boolean"
        )  # 해당 트랜잭션에 대해 StartTransaction.conf에서 승인 상태를 수신받지 못한 경우, 충전 포인트가 진행중인 트랜잭션을 중지할 것인지에 대한 여부
        bulkInsertData.append(stopTransactionOnInvalidId)

        stopTxnAlignedData = self.model(
            required=True,
            write_accessibility=True,
            key="StopTxnAlignedData",
            value="CSL",
            description="CSL"
        )
        # 과금세션의 모든 ClockAlignedDataInterval에 대한 StopTransaction.req와
        # MeterValues.req PDU의 트랜잭션 데이터 요소에 포함될 클럭 정렬 주기 측정량
        bulkInsertData.append(stopTxnAlignedData)

        stopTxnAlignedDataMaxLength = self.model(
            required=False,
            write_accessibility=False,
            key="StopTxnAlignedDataMaxLength",
            value=0,
            description="int"
        )  # StopTxnAlignedData 설정키의 최대 항목 수
        bulkInsertData.append(stopTxnAlignedDataMaxLength)

        stopTxnSampledData = self.model(
            required=False,
            write_accessibility=False,
            key="StopTxnSampledData",
            value=0,
            description="int"
        )  # StopTxnSampledData 설정키의 최대 항목 수
        bulkInsertData.append(stopTxnSampledData)

        stopTxnSampledDataMaxLength = self.model(
            required=False,
            write_accessibility=False,
            key="StopTxnSampledDataMaxLength",
            value=0,
            description="int"
        )  # StopTxnSampledData 설정키의 최대 항목 수
        bulkInsertData.append(stopTxnSampledDataMaxLength)

        supportedFeatureProfiles = self.model(
            required=True,
            write_accessibility=False,
            key="SupportedFeatureProfiles",
            value="Core",
            description="CSL"
        )
        # 지원되는 기능 프로필의 목록.
        # (Core, FirmwareManagement, LocalAuthListManagement, Reservation, SmartCharging, Remote Trigger)
        bulkInsertData.append(supportedFeatureProfiles)

        supportedFeatureProfilesMaxLength = self.model(
            required=True,
            write_accessibility=True,
            key="SupportedFeatureProfilesMaxLength",
            value=0,
            description="int(times) - min인것으로 추정"
        )  # SupportedFeatureProfiles 설정키의 최대 항목 수
        bulkInsertData.append(supportedFeatureProfilesMaxLength)

        transactionMessageAttempts = self.model(
            required=True,
            write_accessibility=True,
            key="TransactionMessageAttempts",
            value=1,
            description="int(times) - min"
        )  # 중앙시스템이 트랜잭션 관련 메시지를 처리하는데 실패한 경우, 충전 포인트가 관련 메시지를 제출하려고 시도하는 빈도
        bulkInsertData.append(transactionMessageAttempts)

        transactionMessageRetryInterval = self.model(
            required=True,
            write_accessibility=True,
            key="TransactionMessageRetryInterval",
            value=1,
            description="int(sec)"
        )  # 중앙시스템이 처리하지 못한 트랜잭션 관련 메시지를 다시 전송하기 전 충전 포인트가 대기해야 하는 시간
        bulkInsertData.append(transactionMessageRetryInterval)

        unlockConnectorOnEVSideDisconnect = self.model(
            required=True,
            write_accessibility=True,
            key="UnlockConnectorOnEVSideDisconnect",
            value=True,
            description="Boolean"
        )  # 'true'로 설정하면 충전 포인트는 케이블이 EV에서 분리 될 때 충전 포인트 측면에서 케이블의 잠금을 해제한다.
        bulkInsertData.append(unlockConnectorOnEVSideDisconnect)

        webSocketPingInterval = self.model(
            required=False,
            write_accessibility=True,
            key="WebSocketPingInterval",
            value=0,
            description="int(sec)"
        )
        # WebSocket을 활용하여 구현하는 경우에만 관련이 있다.
        # ‘0’의 값을 가지면 클라이언트 측 WebSocket ping / pong을 비활성화 한다.
        # 양수 값은 핑 사이의 초 수를 의미한다.
        # 음수 값은 허용되지 않는다. 설정 변경은 거절 결과를 반환 할 것이다.
        bulkInsertData.append(webSocketPingInterval)

        a = self.model.bulk_create(bulkInsertData)
        print(a)
        return self.model.select()

    def getConfigurationAll(self):
        confData = self.conf
        if confData == {}:
            conf = self.model.select()
            buffer = {}
            length = len(conf)

            if length == 0:
                conf = self.configurationInitialize()

            if len(self.conf) == 0:
                for target in conf:
                    buffer[target.key] = target
                self.conf = buffer

        return confData

    def getConfigurationByKey(self, key):
        result = self.conf[key]
        return result

    def setConfiguration(self, key, value):
        try:
            result = self.getConfigurationByKey(key)
            if result.write_accessibility is False:
                return ConfigurationStatus.Rejected.name

            valid = self.valueValidator(key, value)
            if valid == ConfigurationStatus.Accepted.name:
                self.conf[key].value = value
                self.model.update(value=value).where(self.model.key == key)
                return ConfigurationStatus.Accepted.name
            if valid == ConfigurationStatus.Rejected.name:
                return ConfigurationStatus.Rejected.name
            if valid == ConfigurationStatus.NotSupported.name:
                return ConfigurationStatus.NotSupported.name
        except Exception as e:
            print(e)

