import asyncio
import ssl

import websockets
import json
from datetime import datetime

from src.constants import (
    ChargerStatus,
    ChargerActiveStatus,
    NotificationStatus,
    ScenarioType,
)
from ocpp.v16.constants import (
    AuthorizationStatus,
    Action,
    DataTransferStatus,
    DataTransferMessageId,
    RegistrationStatus, OcppErrorCode,
)
from validation.validator import validate
from ocpp.v16.message.CallError import CallError
TEST_START_LOGIC = None
# TEST_START_LOGIC = "StartTest"


class WebSocketClient:
    def __init__(self, deviceInfo):
        self.ws = None
        self.message = None
        self.status = None
        self.mcu = None
        self.model = None
        self.disConnectionCnt = 0
        self.disConnectRetryCnt = 5
        self.disConnectRetryInterval = 5

        self.Server_uri = deviceInfo["Web_Socket"]
        self.pullPath = self.Server_uri + '/ocpp/'

    def setMCU(self, mcu):
        self.mcu = mcu

    def setModel(self, model):
        self.model = model

    async def disconnect(self):
        if self.ws is not None:
            await self.ws.close()
            self.ws = None

    async def send(self, data):
        try:
            if self.ws is not None:
                if type(data) is list:
                    sendData = json.dumps(data)
                    await self.ws.send(sendData)
        except Exception as e:
            print("send Function Exception")
            print(e)
            raise e

    async def recv(self):
        try:
            if self.ws is not None:
                response = await self.ws.recv()
                if type(response) == bytes or type(response) == str:
                    return json.loads(response)

                return None
        except Exception as e:
            print("recv Function Exception")
            print(e)
            raise e

    def insertMessage(self, insertData):
        try:
            ocpp = self.model(
                is_remote=insertData["isRemote"],
                unique_id=insertData["uniqueId"],
                action=insertData["action"],
                request_payload=insertData["requestMessage"],
                request_at=datetime.utcnow()
            )
            ocpp.save()
        except Exception as e:
            print("insertMessage Function Exception")
            print(e)
            raise e

    def updateMessage(self, uniqueId, updateData):
        try:
            update = self.model.update(
                response_payload=updateData["responseMessage"],
                response_at=datetime.utcnow()
            ).where(self.model.unique_id == uniqueId)
            update.execute()
        except Exception as e:
            print("updateMessage Function Exception")
            print(e)
            raise e

    def getPriceAmt(self, payload):
        data = json.loads(payload['data'])

        if "SeasonPrice" in data:
            price = data["SeasonPrice"]
            targetAmt = data["TargetAmt"]
            reason = data["Reason"]

            nowTime = datetime.utcnow()

            for priceData in price:
                start = datetime.strptime(priceData["stime"], '%Y-%m-%dT%H:%M:%SZ')
                end = datetime.strptime(priceData["etime"], '%Y-%m-%dT%H:%M:%SZ')
                amt = priceData["amt"]
                if start <= nowTime <= end:
                    return amt
        elif "UnitPrice" in data:
            return data["UnitPrice"]

        return 0

    async def requestAction(self, message):
        print("request To CSMS")

        messageType = message[0]
        uniqueId = message[1]
        action = message[2]
        payload = message[3]

        print(message)

        insertData = {
            "isRemote": 0,
            "uniqueId": uniqueId,
            "action": action,
            "requestMessage": message
        }
        try:
            if TEST_START_LOGIC is None:
                self.insertMessage(insertData)
                await self.send(message)
            # else:
            #     self.testSend(action)
            #     self.insertMessage(insertData)

        except Exception as e:
            print("requestAction Function Exception")
            print(e)
            raise e

    async def responseActions(self, message):
        print("requestActions")
        messageType = message[0]
        uniqueId = message[1]
        payload = None
        errorCode = None
        errorDescription = None
        errorDetails = None
        try:
            if messageType == 3:
                payload = message[2]
            elif messageType == 4:
                errorCode = message[2]
                errorDescription = message[3]
                errorDetails = message[4]

            targetRow = self.model.select().where(self.model.unique_id == uniqueId)
            if len(targetRow) == 0:
                return
            action = targetRow[0].action

            updateData = {
                "responseMessage": message
            }
            self.updateMessage(uniqueId, updateData)

            validate(action, payload)

            mcuStatus = self.mcu.getStatus()

            if payload is not None:
                if action == Action.BootNotification.name:
                    if RegistrationStatus.Accepted.name == payload["status"]:
                        self.mcu.setHeartbeatInterval(payload["interval"])
                        self.mcu.setBootAccept(True)
                    else:
                        self.mcu.setHeartbeatInterval(payload["interval"])
                        self.mcu.bootRejectCntIncrease()
                        print("BootNotification Fail")

                if action == Action.Authorize.name:
                    idTagInfo = payload["idTagInfo"]
                    if AuthorizationStatus.Accepted.name == idTagInfo["status"]:
                        self.mcu.setAcceptAuthOcpp("Accepted")
                    elif AuthorizationStatus.Blocked.name == idTagInfo["status"]:
                        print("Authorize Blocked")
                        self.mcu.setStatus(ChargerStatus.Block.name)
                    elif AuthorizationStatus.Expired.name == idTagInfo["status"]:
                        print("Authorize Expired")
                        self.mcu.setStatus(ChargerStatus.Block.name)
                    elif AuthorizationStatus.Invalid.name == idTagInfo["status"]:
                        print("Authorize Invalid")
                        self.mcu.setStatus(ChargerStatus.Block.name)

                if action == Action.StatusNotification.name:
                    chargingStatus = self.mcu.getChargingStatus()
                    finishStatus = self.mcu.getFinishStatus()
                    if mcuStatus == ChargerStatus.Finish.name:
                        if finishStatus == ChargerActiveStatus.FinishStatus_1.name:
                            self.mcu.setFinishStatus(ChargerActiveStatus.FinishStatus_2.name)
                    elif mcuStatus == ChargerStatus.Charging.name:
                        if chargingStatus is None:
                            self.mcu.setChargingStatus(ChargerActiveStatus.REQ_PRICE.name)
                    elif mcuStatus == ChargerStatus.RemoteStart.name:
                        self.mcu.setRemoteChargingStatus(ChargerActiveStatus.REQ_PRICE.name)

                if action == Action.StartTransaction.name:
                    idTagInfo = payload["idTagInfo"]
                    transId = payload["transactionId"]
                    if AuthorizationStatus.Accepted.name == idTagInfo["status"]:
                        self.mcu.setTransactionId(transId)
                        self.mcu.setStartTransactionResult(True)

                    elif AuthorizationStatus.Blocked.name in idTagInfo["status"]:
                        self.mcu.setStatus(ChargerStatus.InitializeData.name)

                if action == Action.StopTransaction.name:
                    idTagInfo = payload["idTagInfo"]
                    deviceOcppStatus = self.mcu.getDeviceOcppStatus()
                    if AuthorizationStatus.Accepted.name == idTagInfo["status"]:
                        print("stopTransaction res deviceOcppStatus : " + deviceOcppStatus)
                        if deviceOcppStatus != ChargerStatus.Fault.name:
                            self.mcu.setFinishStatus(ChargerActiveStatus.FinishStatus_1.name)
                        else:
                            self.mcu.setStatus(ChargerStatus.Fault.name)

                if action == Action.DataTransfer.name:
                    chargingStatus = self.mcu.getChargingStatus()
                    remoteChargingStatus = self.mcu.getRemoteChargingStatus()

                    if DataTransferStatus.Accepted.name == payload["status"]:
                        if DataTransferMessageId.REQ_PRICE.name == chargingStatus or \
                                DataTransferMessageId.REQ_PRICE.name == remoteChargingStatus:

                            price = self.getPriceAmt(payload)

                            self.mcu.setPrice(price)
                            print("REQ_PRICE")
                        if DataTransferMessageId.REQ_CHARGE_AMT.name == chargingStatus:
                            if "chargereqAmt" in payload:
                                self.mcu.setChargeAmt(payload["chargereqAmt"])
                                print("chargereqAmt : ", payload["chargereqAmt"])
                        self.mcu.setDataTransAccept(True)
                    elif DataTransferStatus.Rejected.name == payload["status"]:
                        self.mcu.setStatus(ChargerStatus.Block.name)
                        print("DataTransfer Rejected")
                    elif DataTransferStatus.UnknownMessageId.name == payload["status"]:
                        self.mcu.setStatus(ChargerStatus.Block.name)
                        print("DataTransfer UnknownMessageId")
                    elif DataTransferStatus.UnknownVendorId.name == payload["status"]:
                        self.mcu.setStatus(ChargerStatus.Block.name)
                        print("DataTransfer UnknownVendorId")

            else:
                print("fail action : ", action)
                print("error code : ", errorCode)
                print("error description : ", errorDescription)
                print("error details : ", errorDetails)

            # MeterValue, Heartbeat 는 response 가 없어 정의 하지 않음
            # DB에 저장만 한다
        except Exception as e:
            print("responseActions Function Exception")
            print(e)

    async def remoteResult(self, message):
        print("remoteResult")
        messageType = message[0]
        uniqueId = message[1]
        payload = message[2]

        try:
            await self.send(message)

            updateData = {
                "responseMessage": message
            }
            self.updateMessage(uniqueId, updateData)

        except Exception as e:
            print("remoteResult Function Exception")
            print(e)
            raise e

    async def remoteActions(self, message):
        print("remoteActions")
        messageType = message[0]
        uniqueId = message[1]
        action = message[2]
        payload = message[3]

        insertData = {
            "isRemote": 1,
            "uniqueId": uniqueId,
            "action": action,
            "requestMessage": message
        }
        try:
            self.insertMessage(insertData)

            mcuStatus = self.mcu.getStatus()

            validate(action, payload)

            if messageType == 2:
                if action == Action.RemoteStartTransaction.name:
                    if mcuStatus == ChargerStatus.Ready.name:
                        print("---------------------------------")
                        print("RemoteStartTransaction running")
                        print("---------------------------------")

                        if "idTag" in payload:
                            await self.mcu.remoteStartResult(uniqueId, True)
                            idTag = payload["idTag"]
                            self.mcu.setScenarioType(ScenarioType.Remote.name)
                            self.mcu.setStatus(ChargerStatus.Tagging.name)
                            self.mcu.setIdTag(idTag)
                        else:
                            await self.mcu.remoteStartResult(uniqueId, False)

                    else:
                        print("RemoteStartTransaction Fail")
                        await self.mcu.remoteStartResult(uniqueId, False)

                elif action == Action.RemoteStopTransaction.name:
                    stopTransactionId = payload['transactionId']
                    if await self.mcu.isTransactionId(uniqueId, stopTransactionId):
                        self.mcu.setStatus(ChargerStatus.Finish.name)
                        self.mcu.setFinishStatus(ChargerActiveStatus.Stop.name)
                        self.mcu.remoteStop = True

                    else:
                        print("RemoteStopTransaction Fail")

                elif action == Action.ChangeConfiguration.name:
                    key = payload['key']
                    value = payload['value']
                    await self.mcu.setConf(uniqueId, key, value)

                elif action == Action.ChangeConfiguration.name:
                    key = payload['key']
                    await self.mcu.getConf(uniqueId, key)

                elif action == Action.Reset.name:
                    print("Not Supported")
                    self.mcu.notSupportedAction(uniqueId, Action.Reset.name)

                elif action == Action.ChangeAvailability.name:
                    print("Not Supported")
                    self.mcu.notSupportedAction(uniqueId, Action.ChangeAvailability.name)

                elif action == Action.UnlockConnector.name:
                    print("Not Supported")
                    self.mcu.notSupportedAction(uniqueId, Action.UnlockConnector.name)

                elif action == Action.UpdateFirmware.name:
                    print("updateFirmware Action")
                    location = payload["location"]
                    retrieveDate = payload["retrieveDate"]

                    await self.mcu.updateFirmwareResponse(uniqueId, location, retrieveDate)

        except Exception as e:
            print("remoteActions Function Exception")
            print(e)
            errorCode = OcppErrorCode.ProtocolError.name
            if isinstance(e, ValueError):
                errorCode = OcppErrorCode.PropertyConstraintViolation.name
            if isinstance(e, KeyError):
                errorCode = OcppErrorCode.TypeConstraintViolation.name
            if isinstance(e, TypeError):
                errorCode = OcppErrorCode.TypeConstraintViolation.name

            err = {
                "errorCode": errorCode,
                "errorDetail": "",
                "errorDescription": str(e)
            }
            callErrorMessage = CallError(uniqueId, err)
            print(callErrorMessage.message)

            await self.remoteResult(callErrorMessage.message)

            raise e

    async def listen(self):
        if self.ws is None:
            try:
                deviceCode = self.mcu.getDeviceCode()
                pullPath = self.pullPath + deviceCode
                # ssl 인증서
                context = ssl._create_unverified_context()
                # ws 연결 시 사용
                # async with websockets.connect(pullPath) as ws:
                # wss 연결 시 사용
                async with websockets.connect(pullPath, ssl=context) as ws:
                    self.ws = ws
                    while True:
                        try:
                            message = await self.recv()
                            print("message: ", message)
                            print("ws: ", self.ws.id)
                            if message is None:
                                continue
                            if isinstance(message, str):
                                continue
                            resMessageType = message[0]

                            if resMessageType == 2:
                                await self.remoteActions(message)
                            elif resMessageType == 3 or resMessageType == 4:
                                await self.responseActions(message)

                            self.disConnectionCnt = 0
                        except Exception as e:
                            print("connect Function Exception")
                            await self.disconnect()
                            self.ws = None
                            print(e)
                            raise e
                        except websockets.ConnectionClosed as e:
                            print("Connection closed.")
                            await self.disconnect()
                            self.ws = None
                            raise e
                        except ws.available_extensions as e:
                            print("Connection closed.")
                            await self.disconnect()
                            self.ws = None
                            raise e
                        finally:
                            await asyncio.sleep(0.1)
            except Exception as e:
                print(e)
                raise e

    async def main(self):
        while True:
            try:
                print("webSocket Class Running")
                await self.listen()
            except Exception as e:
                print("webSocket Class Error")
                await asyncio.sleep(self.disConnectRetryInterval)
                print(e)
            finally:
                print("webSocket Class reStart")
                self.disConnectionCnt += 1

                if self.disConnectionCnt >= self.disConnectRetryCnt:
                    break
