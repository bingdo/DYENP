from src.common import StrEnum
from enum import auto


# 사용자 정의
class ChargerStatus(StrEnum):
    Init = auto()
    InitializeData = auto()
    Ready = auto()
    Tagging = auto()
    Authorize = auto()
    Charging = auto()
    RemoteStart = auto()
    Finish = auto()
    Block = auto()
    Fault = auto()
    Comm_fault = auto()
    Update = auto()


class ChargerActiveStatus(StrEnum):
    REQ_PRICE = auto()
    REQ_CHARGE_AMT = auto()
    REQ_VAN_PRE = auto()
    PlugCheck = auto()
    StartTransaction = auto()
    StopTransaction = auto()
    RemoteStopTransaction = auto()
    MeterValue = auto()
    Stop = auto()
    FinishStatus_1 = auto()
    FinishStatus_2 = auto()
    Finish = auto()


class NotificationStatus(StrEnum):
    Ready = auto()
    Charging = auto()
    Finish = auto()
    Preparing = auto()
    Fault = auto()
    Comm_fault = auto()
    Unavailable = auto()


class ScenarioType(StrEnum):
    Card_Tagging = auto()
    Remote = auto()
    Non_Member = auto()


