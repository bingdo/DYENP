import shortuuid


class Call:
    def __init__(self, action, payload):
        self.messageTypeId = 2
        self.uniqueId = shortuuid.uuid()
        self.action = action
        self.payload = payload
        self.message = [self.messageTypeId, self.uniqueId, self.action, self.payload]

