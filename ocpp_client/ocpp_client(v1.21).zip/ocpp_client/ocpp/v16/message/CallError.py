class CallError:
    def __init__(self, uniqueId, error):
        self.messageTypeId = 4
        self.uniqueId = uniqueId
        self.errorCode = error["errorCode"]
        self.errorDescription = error["errorDescription"]
        self.errorDetail = error["errorDetail"]
        self.message = [self.messageTypeId, self.uniqueId, self.errorCode, self.errorDescription, self.errorDetail]
