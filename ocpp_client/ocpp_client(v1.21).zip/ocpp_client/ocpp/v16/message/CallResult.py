class CallResult:
    def __init__(self, uniqueId, payload):
        self.messageTypeId = 3
        self.uniqueId = uniqueId
        self.payload = payload
        self.message = [self.messageTypeId, self.uniqueId, self.payload]
