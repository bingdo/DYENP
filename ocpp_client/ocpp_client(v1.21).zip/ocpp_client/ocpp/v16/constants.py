from src.common import StrEnum
from enum import auto
from dataclasses import dataclass
from typing import List, Optional
from json import dumps

from datetime import date


class Action(StrEnum):
    # CORE, FIRMWARE MANAGEMENT
    Authorize = auto()
    BootNotification = auto()
    ChangeAvailability = auto()
    ChangeConfiguration = auto()
    ClearCache = auto()
    DataTransfer = auto()
    GetConfiguration = auto()
    Heartbeat = auto()
    MeterValues = auto()
    RemoteStartTransaction = auto()
    RemoteStopTransaction = auto()
    Reset = auto()
    StartTransaction = auto()
    StatusNotification = auto()
    StopTransaction = auto()
    UnlockConnector = auto()
    GetDiagnostics = auto()
    DiagnosticsStatusNotification = auto()
    FirmwareStatusNotification = auto()
    UpdateFirmware = auto()


class AuthorizationStatus(StrEnum):
    Accepted = auto()
    Blocked = auto()
    Expired = auto()
    Invalid = auto()
    ConcurrentTx = auto()


class OcppErrorCode(StrEnum):
    NotImplemented = auto()
    NotSupported = auto()
    InternalError = auto()
    ProtocolError = auto()
    SecurityError = auto()
    FormationViolation = auto()
    PropertyConstraintViolation = auto()
    OccurenceConstraintViolation = auto()
    TypeConstraintViolation = auto()
    GenericError = auto()


class ChargePointErrorCode(StrEnum):
    ConnectorLockFailure = auto()
    EVCommunicationError = auto()
    GroundFailure = auto()
    HighTemperature = auto()
    InternalError = auto()
    LocalListConflict = auto()
    NoError = auto()
    OtherError = auto()
    OverCurrentFailure = auto()
    OverVoltage = auto()
    PowerMeterFailure = auto()
    PowerSwitchFailure = auto()
    ReaderFailure = auto()
    ResetFailure = auto()
    UnderVoltage = auto()
    WeakSignal = auto()


class ChargePointStatus(StrEnum):
    Available = auto()
    Preparing = auto()
    Charging = auto()
    SuspendedEVSE = auto()
    SuspendedEV = auto()
    Finishing = auto()
    Reserved = auto()
    Unavailable = auto()
    Faulted = auto()


class DataTransferMessageId(StrEnum):
    REQ_PRICE = auto()  # 충전 단가 요청
    REQ_CHARGE_AMT = auto()  # 충전 금액 전송
    REQ_VAN_PRE = auto()  # 비회원 선결제
    REQ_VAN_POST = auto()  # 비회원 선결제 취소
    REQ_DIS_PRICE = auto()  # 충전기 화면 단가 요청


class DataTransferStatus(StrEnum):
    Accepted = auto()
    Rejected = auto()
    UnknownMessageId = auto()
    UnknownVendorId = auto()


class ReadingContext(StrEnum):
    Interruption_Begin = "Interruption.Begin"
    Interruption_End = "Interruption.End"
    Other = auto()
    Sample_Clock = "Sample.Clock"
    Sample_Periodic = "Sample.Periodic"
    Transaction_Begin = "Transaction.Begin"
    Transaction_End = "Transaction.End"
    Trigger = auto()


class RegistrationStatus(StrEnum):
    Accepted = auto()
    Pending = auto()
    Rejected = auto()


class ValueFormat(StrEnum):
    Raw = auto()
    SignedData = auto()


class Measurand(StrEnum):
    Current_Export = "Current.Export"
    Current_Import = "Current.Import"
    Current_Offered = "Current.Offered"
    Energy_Active_Export_Register = "Energy.Active.Export.Register"
    Energy_Active_Import_Register = "Energy.Active.Import.Register"
    Energy_Reactive_Export_Register = "Energy.Reactive.Export.Register"
    Energy_Reactive_Import_Register = "Energy.Reactive.Import.Register"
    Energy_Active_Export_Interval = "Energy.Active.Export.Interval"
    Energy_Active_Import_Interval = "Energy.Active.Import.Interval"
    Energy_Reactive_Export_Interval = "Energy.Reactive.Export.Interval"
    Energy_Reactive_Import_Interval = "Energy.Reactive.Import.Interval"
    Frequency = auto()
    Power_Active_Export = "Power.Active.Export"
    Power_Active_Import = "Power.Active.Import"
    Power_Factor = "Power.Factor"
    Power_Offered = "Power.Offered"
    Power_Reactive_Export = "Power.Reactive.Export"
    Power_Reactive_Import = "Power.Reactive.Import"
    RPM = auto()
    SoC = auto()
    Temperature = auto()
    Voltage = auto()


class Phase(StrEnum):
    L1 = auto()
    L2 = auto()
    L3 = auto()
    N = auto()
    L1_N = "L1-N"
    L2_N = "L2-N"
    L3_N = "L3-N"
    L1_L2 = "L1-L2"
    L2_L3 = "L2-L3"
    L3_L1 = "L3-L1"


class UnitOfMeasure(StrEnum):
    Wh = auto()
    kWh = auto()
    varh = auto()
    kvarh = auto()
    W = auto()
    kW = auto()
    VA = auto()
    kVA = auto()
    var = auto()
    kvar = auto()
    A = auto()
    V = auto()
    Celsius = auto()
    Fahrenheit = auto()
    K = auto()
    Percent = auto()


class Location(StrEnum):
    Body = auto()
    Cable = auto()
    EV = auto()
    Inlet = auto()
    Outlet = auto()


class Reason(StrEnum):
    DeAuthorized = auto()
    EmergencyStop = auto()
    EVDisconnected = auto()
    HardReset = auto()
    Local = auto()
    Other = auto()
    PowerLoss = auto()
    Reboot = auto()
    Remote = auto()
    SoftReset = auto()
    UnlockCommand = auto()


class FirmwareStatus(StrEnum):
    Downloaded = auto()
    DownloadFailed = auto()
    Downloading = auto()
    Idle = auto()
    InstallationFailed = auto()
    Installing = auto()
    Installed = auto()


class CrocusDataTransferMessageId(StrEnum):
    REQ_PRICE = auto()
    REQ_CHARGE_AMT = auto()
    REQ_VAN_PRE = auto()
    REQ_VAN_POST = auto()
    REQ_DIS_PRICE = auto()


class RemoteStartStopStatus(StrEnum):
    Accepted = auto()
    Rejected = auto()


class ConfigurationStatus(StrEnum):
    Accepted = auto()
    Rejected = auto()
    RebootRequired = auto()
    NotSupported = auto()


class UnlockStatus(StrEnum):
    Unlocked = auto()
    UnlockFailed = auto()
    NotSupported = auto()


class ResetStatus(StrEnum):
    Accepted = auto()
    Rejected = auto()


class ResetType(StrEnum):
    Soft = auto()
    Hard = auto()


class AvailabilityStatus(StrEnum):
    Accepted = auto()
    Rejected = auto()
    Scheduled = auto()


class AvailabilityType(StrEnum):
    Inoperative = auto()
    Operative = auto()


class ClearCacheStatus(StrEnum):
    Accepted = auto()
    Rejected = auto()


@dataclass
class TypeClass:
    @property
    def json(self):
        for k, v in list(self.__dict__.items()):
            if v is None:
                self.__dict__.pop(k)
        return self.__dict__



@dataclass
class IdTagInfo(TypeClass):
    status: AuthorizationStatus
    expiryDate: Optional[str] = None
    parentIdTag: Optional[str] = None


@dataclass
class SampledValue(TypeClass):
    value: str
    context: Optional[ReadingContext] = None
    format: Optional[ValueFormat] = None
    measurand: Optional[Measurand] = None
    phase: Optional[Phase] = None
    location: Optional[Location] = None
    unit: Optional[UnitOfMeasure] = None


@dataclass
class MeterValue(TypeClass):
    timestamp: str
    sampledValue: List[SampledValue]


@dataclass
class ReqPrice(TypeClass):
    connectorId: str
    idTag: str


@dataclass
class ReqChargeAmt(TypeClass):
    connectorId: str
    chargereqAmt: int
    idTag: str


@dataclass
class ReqVanPre(TypeClass):
    connectorId: str
    PhoneNo: str
    Paybuz: str
    PayKind: str
    reqAmt: int
    timestamp: str
    TransactionNo: str


@dataclass
class ReqVanPost(TypeClass):
    connectorId: str
    PhoneNo: str
    Paybuz: str
    PayKind: str
    reqAmt: int
    timestamp: str
    TransactionNo: str
    ApprovalNo: str


class ReqDisPrice(TypeClass):
    connectorId: str

