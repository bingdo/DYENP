from src.common import StrEnum
from enum import auto, Enum
from pydantic import BaseModel, validator


def intTypeValidator(value):
    if value < 0:
        return False
    return True


class AllowOfflineTxForUnkownId(BaseModel):
    value: bool


class AuthorizationCacheEnabled(BaseModel):
    value: bool


class AuthorizeRemoteTxRequests(BaseModel):
    value: bool


class BlinkRepeat(BaseModel):
    value: int


class ClockAlignedDataInterval(BaseModel):
    value: int


class ConnectionTimeOut(BaseModel):
    value: int


class GetConfigurationMaxKeys(BaseModel):
    value: int


class HeartbeatInterval(BaseModel):
    value: int


class LightIntensity(BaseModel):
    value: int


class LocalAuthorizeOffline(BaseModel):
    value: bool


class LocalPreAuthorize(BaseModel):
    value: bool


class MaxEnergyOnInvalidId(BaseModel):
    value: int


class MeterValuesAlignedData(BaseModel):
    value: "cls"


class MeterValuesAlignedDataMaxLength(BaseModel):
    value: int


class MeterValuesSampledData(BaseModel):
    value: "cls"


class MeterValuesSampledDataMaxLength(BaseModel):
    value: int


class MeterValueSampleInterval(BaseModel):
    value: int

class MinimumStatusDuration(BaseModel):
    value: int


class NumberOfConnectors(BaseModel):
    value: int


class ResetRetries(BaseModel):
    value: int


class ConnectorPhaseRotation(BaseModel):
    value: "cls"

class ConnectorPhaseRotationMaxLength(BaseModel):
    value: int


class StopTransactionOnEVSideDisconnect(BaseModel):
    value: bool


class StopTransactionOnInvalidId(BaseModel):
    value: bool


class StopTxnAlignedData(BaseModel):
    value: "cls"


class StopTxnAlignedDataMaxLength(BaseModel):
    value: int


class StopTxnSampledData(BaseModel):
    value: int


class StopTxnSampledDataMaxLength(BaseModel):
    value: int


class SupportedFeatureProfiles(BaseModel):
    value: "CLS"


class SupportedFeatureProfilesMaxLength(BaseModel):
    value: int


class TransactionMessageAttempts(BaseModel):
    value: int


class TransactionMessageRetryInterval(BaseModel):
    value: int


class UnlockConnectorOnEVSideDisconnect(BaseModel):
    value: bool


class WebSocketPingInterval(BaseModel):
    value: int


class KeyList(StrEnum):
    AllowOfflineTxForUnkownId = auto()
    AuthorizationCacheEnabled = auto()
    AuthorizeRemoteTxRequests = auto()
    BlinkRepeat = auto()
    ClockAlignedDataInterval = auto()
    ConnectionTimeOut = auto()
    GetConfigurationMaxKeys = auto()
    HeartbeatInterval = auto()
    LightIntensity = auto()
    LocalAuthorizeOffline = auto()
    LocalPreAuthorize = auto()
    MaxEnergyOnInvalidId = auto()
    MeterValuesAlignedData = auto()
    MeterValuesAlignedDataMaxLength = auto()
    MeterValuesSampledData = auto()
    MeterValuesSampledDataMaxLength = auto()
    MeterValueSampleInterval = auto()
    MinimumStatusDuration = auto()
    NumberOfConnectors = auto()
    ResetRetries = auto()
    ConnectorPhaseRotation = auto()
    ConnectorPhaseRotationMaxLength = auto()
    StopTransactionOnEVSideDisconnect = auto()
    StopTransactionOnInvalidId = auto()
    StopTxnAlignedData = auto()
    StopTxnAlignedDataMaxLength = auto()
    StopTxnSampledData = auto()
    StopTxnSampledDataMaxLength = auto()
    SupportedFeatureProfiles = auto()
    SupportedFeatureProfilesMaxLength = auto()
    TransactionMessageAttempts = auto()
    TransactionMessageRetryInterval = auto()
    UnlockConnectorOnEVSideDisconnect = auto()
    WebSocketPingInterval = auto()
