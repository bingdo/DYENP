from peewee import *
from datetime import datetime

db = SqliteDatabase('chargerDB.db')
# db.close()


class Charger(Model):
    id: AutoField()
    charger_status = CharField()
    charger_version = CharField()
    run_count = IntegerField()
    card_number = CharField()
    total_power = FloatField()
    power_now = FloatField()
    output_voltage = FloatField(null=True)
    output_current = FloatField(null=True)
    SOC = FloatField(null=True)
    running_time = TimeField(null=True)
    target_voltage = FloatField(null=True)
    target_current = FloatField(null=True)
    version = CharField(null=True)
    fault = CharField(null=True)
    charger_serial_number = CharField()
    manufacturer_option = CharField(null=True)
    connector_box_info = CharField(null=True)
    charging_total_power = CharField(null=True)
    nfc = CharField(null=True)
    create_date = DateTimeField(default=datetime.now)

    class Meta:
        database = db


class OcppMessage(Model):
    id: AutoField()
    is_remote = BooleanField()
    unique_id = CharField(unique=True)
    action = CharField()
    request_payload = CharField()
    request_at = DateTimeField()
    response_payload = CharField(null=True)
    response_at = DateTimeField(null=True)

    class Meta:
        database = db


class Configuration(Model):
    id: AutoField()
    required = BooleanField()
    write_accessibility = BooleanField()
    key = CharField()
    value = CharField()
    description = DateTimeField()

    class Meta:
        database = db


def closeDB(database):
    database.close()


db.connect()
db.create_tables([Charger, OcppMessage, Configuration])
