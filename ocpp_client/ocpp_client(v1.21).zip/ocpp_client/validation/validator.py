from ocpp.v16.constants import Action
from ocpp.v16.commands import (
    AuthorizeResPayload,
    BootNotificationResPayload,
    StartTransactionResPayload,
    StopTransactionResPayload,
    RemoteStartTransactionReqPayload,
    RemoteStopTransactionReqPayload,
    ResetReqPayload,
    UnlockConnectorReqPayload,
    ChargeAvailabilityReqPayload,
    GetConfigurationReqPayload,
    ChangeConfigurationReqPayload,
)


def validate(action, payload):
    try:
        if action == Action.Authorize.name:
            AuthorizeResPayload(**payload)
        elif action == Action.BootNotification.name:
            BootNotificationResPayload(**payload)
        # elif action == Action.StartTransaction.name:
        #     StartTransactionResPayload(**payload)
        # elif action == Action.StopTransaction.name:
        #     StopTransactionResPayload(**payload)
        elif action == Action.RemoteStartTransaction.name:
            RemoteStartTransactionReqPayload(**payload)
        elif action == Action.RemoteStopTransaction.name:
            RemoteStopTransactionReqPayload(**payload)
        elif action == Action.Reset.name:
            ResetReqPayload(**payload)
        elif action == Action.UnlockConnector.name:
            UnlockConnectorReqPayload(**payload)
        elif action == Action.ChangeAvailability.name:
            ChargeAvailabilityReqPayload(**payload)
        elif action == Action.ChangeConfiguration.name:
            ChangeConfigurationReqPayload(**payload)
        elif action == Action.GetConfiguration.name:
            GetConfigurationReqPayload(**payload)
    except Exception as e:
        raise e

