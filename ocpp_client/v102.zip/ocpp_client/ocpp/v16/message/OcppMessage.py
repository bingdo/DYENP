from abc import *


class OcppMessage(metaclass=ABCMeta):
    @abstractmethod
    def validate(self): pass
    @abstractmethod
    def makeMessage(self): pass
