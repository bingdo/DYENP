from dataclasses import dataclass
from enum import auto
from typing import List, Optional, Union
from datetime import datetime
from json import dumps

from pydantic import BaseModel, StrictStr, StrictInt, StrictBool

from src.common import StrEnum


from ocpp.v16.constants import (
    ChargePointErrorCode,
    ChargePointStatus,
    MeterValue,
    Reason,
    FirmwareStatus,
    CrocusDataTransferMessageId,
    ReqPrice,
    ReqChargeAmt,
    ReqVanPre,
    RemoteStartStopStatus,
    IdTagInfo,
    RegistrationStatus,
    ConfigurationStatus,
    ResetStatus,
    AvailabilityStatus,
    ClearCacheStatus,
    UnlockStatus, ResetType, AvailabilityType,
)


@dataclass
class CommandPayload:
    @property
    def json(self):
        for k, v in list(self.__dict__.items()):
            if v is None:
                self.__dict__.pop(k)
        return self.__dict__


@dataclass
class AuthorizeReqPayload(CommandPayload):
    idTag: StrictStr


@dataclass
class BootNotificationReqPayload(CommandPayload):
    chargePointModel: StrictStr
    chargePointVendor: StrictStr
    chargeBoxSerialNumber: Optional[StrictStr] = None
    chargePointSerialNumber: Optional[StrictStr] = None
    firmwareVersion: Optional[StrictStr] = None
    iccid: Optional[StrictStr] = None
    imsi: Optional[StrictStr] = None
    meterSerialNumber: Optional[StrictStr] = None
    meterType: Optional[StrictStr] = None


@dataclass
class StatusNotificationReqPayload(CommandPayload):
    connectorId: StrictInt
    errorCode: ChargePointErrorCode
    status: ChargePointStatus
    info: Optional[StrictStr] = None
    timestamp: Optional[StrictStr] = None
    vendorId: Optional[StrictStr] = None
    vendorErrorCode: Optional[StrictStr] = None


@dataclass
class StartTransactionReqPayload(CommandPayload):
    connectorId: StrictInt
    idTag: StrictStr
    meterStart: StrictInt
    reservationId: Optional[StrictInt] = None # OCPP 처리서버에서 validation 가능한지 여부 확인
    timestamp: Optional[StrictStr] = None


@dataclass
class StopTransactionReqPayload(CommandPayload):
    idTag: StrictStr
    meterStop: StrictInt
    timestamp: StrictStr
    transactionId: StrictInt
    transactionData: Optional[List[MeterValue]] = None
    reason: Optional[Reason] = None


@dataclass
class RemoteStartTransactionResPayload(CommandPayload):
    status: RemoteStartStopStatus


@dataclass
class RemoteStopTransactionResPayload(CommandPayload):
    status: RemoteStartStopStatus


@dataclass
class MeterValueReqPayload(CommandPayload):
    connectorId: StrictInt
    transactionId: StrictInt
    meterValue: List[MeterValue]


@dataclass
class UpdateFirmwareReqPayload(CommandPayload):
    location: StrictStr
    retrieveDate: StrictStr
    retries: Optional[StrictInt] = None
    retryInterval: Optional[StrictInt] = None


@dataclass
class FirmwareStatusNotificationReqPayload(CommandPayload):
    status: FirmwareStatus


@dataclass
class DataTransferReqPayload(CommandPayload):
    vendorId: StrictStr
    messageId: Optional[CrocusDataTransferMessageId] = None
    data: Optional[Union[ReqPrice,ReqChargeAmt,ReqVanPre]] = None


@dataclass
class GetConfigurationResPayload(CommandPayload):
    key: StrictStr
    readonly: StrictBool
    value: Optional[StrictStr] = None


@dataclass
class ChangeConfigurationResPayload(CommandPayload):
    status: ConfigurationStatus


@dataclass
class ResetResPayload(CommandPayload):
    status: ResetStatus


@dataclass
class ChangeAvailabilityResPayload(CommandPayload):
    status: AvailabilityStatus


@dataclass
class ClearCacheResPayload(CommandPayload):
    status: ClearCacheStatus


@dataclass
class UnlockConnectorResPayload(CommandPayload):
    status: UnlockStatus


# CSMS -> CP 메시지 검증


class AuthorizeResPayload(BaseModel):
    idTagInfo: IdTagInfo


class BootNotificationResPayload(BaseModel):
    currentTime: datetime
    status: RegistrationStatus
    interval: StrictInt


class StartTransactionResPayload(BaseModel):
    idTagInfo: IdTagInfo
    transactionId: StrictInt


class StopTransactionResPayload(BaseModel):
    idTagInfo: IdTagInfo


class GetConfigurationReqPayload(BaseModel):
    key: StrictStr


class ChangeConfigurationReqPayload(BaseModel):
    key: StrictStr
    value: StrictStr


class RemoteStopTransactionReqPayload(BaseModel):
    transactionId: StrictInt


class RemoteStartTransactionReqPayload(BaseModel):
    idTag: StrictStr
    connectorId: Optional[StrictInt] = None
    chargingProfile: Optional[StrictStr] = None


class ResetReqPayload(BaseModel):
    type: ResetType


class ChargeAvailabilityReqPayload(BaseModel):
    connectorId: StrictInt
    type: AvailabilityType


class UnlockConnectorReqPayload(BaseModel):
    connectorId: StrictInt
