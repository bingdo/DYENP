import asyncio
import os

from src.MCU import MCU
from src.WebSocket import WebSocketClient
from model import *
import json


def getDeviceInfo():
    deviceInfoPath = "./DeviceInformation.txt"
    jsonData = {}
    if os.path.isfile(deviceInfoPath):
        with open(deviceInfoPath, "r") as f:
            txtData = f.read()
            jsonData = json.loads(txtData)
            f.close()
    else:
        with open(deviceInfoPath, 'w') as f:
            informationData = {
                "Charger_Mode": "CB",
                "Vendor": "CROCUS",
                "Model": "Model 3",
                "Code": "000000",
                "Web_Socket": "wss://crocusev.com:3000"
            }
            f.write(json.dumps(informationData))
            jsonData = informationData
            f.close()

    return jsonData


async def main():
    try:
        ocpp = OcppMessage
        device = Charger

        deviceInfo = getDeviceInfo()

        ws = WebSocketClient(deviceInfo)
        mcu = MCU(deviceInfo)

        ws.setMCU(mcu)
        ws.setModel(ocpp)
        mcu.setWs(ws)
        mcu.setModel(device)

        loop = asyncio.get_event_loop()

        task2 = loop.create_task(ws.main())
        task1 = loop.create_task(mcu.main())
        await task1
        await task2
    except Exception as err:
        print("main function Exception")
        print(err)


try:
    asyncio.run(main())


except Exception as e:
    print(e)
