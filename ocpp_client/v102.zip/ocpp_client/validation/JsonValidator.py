from jsonschema import validate


class JsonValidator:
    def validation(self, schema, data):
        validate(data, schema=schema)
