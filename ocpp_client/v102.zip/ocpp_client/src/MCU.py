import asyncio
import json
import logging
import logging.handlers
import math
import os

from src.ModBus485 import ModBus485
from datetime import datetime, date, timedelta

from ocpp.v16.commands import (
    AuthorizeReqPayload,
    BootNotificationReqPayload,
    StatusNotificationReqPayload,
    StartTransactionReqPayload,
    MeterValueReqPayload,
    StopTransactionReqPayload,
    DataTransferReqPayload,
    RemoteStartTransactionResPayload,
    RemoteStopTransactionResPayload,
    ChangeConfigurationResPayload,
    GetConfigurationResPayload,
    UpdateFirmwareReqPayload,
    ChangeAvailabilityResPayload,
    ResetResPayload,
    ClearCacheResPayload,
    UnlockConnectorResPayload, FirmwareStatusNotificationReqPayload
)

from ocpp.v16.constants import (
    Action,
    ChargePointErrorCode,
    ChargePointStatus,
    MeterValue,
    SampledValue,
    ValueFormat,
    Reason,
    CrocusDataTransferMessageId,
    ReqPrice,
    ReqChargeAmt,
    ReqVanPre,
    RemoteStartStopStatus,
    ReadingContext,
    Measurand,
    Location,
    UnitOfMeasure,
    ConfigurationStatus,
    ResetStatus,
    AvailabilityStatus,
    ClearCacheStatus,
    UnlockStatus,
)
from ocpp.v16.message.Call import Call
from ocpp.v16.message.CallResult import CallResult

from src.Configuration import ConfigurationClass

from src.constants import (
    NotificationStatus,
    ChargerActiveStatus,
    ChargerStatus,
    ScenarioType,
)

TEST_START_LOGIC = None
# TEST_START_LOGIC = "startTest"
DEBUG_LOGGING = False

from ctypes import (
    Union, Array,
    c_uint8, c_float
)


class uint8_array(Array):
    _type_ = c_uint8
    _length_ = 4


class u_type(Union):
    _fields_ = ("data", c_float), ("chunk", uint8_array)


class MCU:
    def __init__(self, deviceInfo):

        self.state = 'stop'

        self.model = None

        self.chargerMode = deviceInfo["Charger_Mode"]
        self.modelName = deviceInfo["Model"]
        self.vendorName = deviceInfo["Vendor"]
        self.deviceCode = deviceInfo["Code"]

        # for Mode Bus 485 Device
        # self.IpAddr = '192.168.1.4'
        self.baseAddr_Write = 200
        self.baseAddr_Read = 400
        self.baseRead_length = 16
        self.modbusWriteAddr = {
            "status": 200,
            "amount": 201,  # 201~202
            "runCount": 203
        }
        self.modbusStatusWriteValue = {
            "authorize_fail": 0,
            "card_authorize": 1,
            "card_registration_mode": 2,
            "mode_local": 4,
            "mode_cb": 8,
            "finish": 16,
        }
        self.CommPort_MCU = '/dev/ttyUSB1'
        # self.CommPort_MCU = '/dev/tty.usbserial-AD0KBPYP'
        self.BaudRate_MCU = 9600
        self.deviceId = 1
        self.connectorId = 1
        # ----------------------------------------
        self.CommErr = 0
        self.conf = ConfigurationClass()

        self.ws = None

        self.logger_MCU = logging.getLogger("mcu_logger")
        self.fileHandler_MCU = None
        self.formatter = logging.Formatter("[%(levelname)s|%(filename)s:%(lineno)s] %(asctime)s > %(message)s")
        self.file_max_bytes = 1 * 1024 * 1024 * 1024  # 10GB

        # MCU Data
        self.maxMCU = 1
        self.maxConnectorCnt = 1

        self.runCnt_HI = 0
        self.runCnt_LO = 0
        self.data = {}
        self.oldData = {}

        self.status = None
        self.connectorStatus = False
        self.deviceOcppOldStatus = None
        self.deviceOcppStatus = None
        self.deviceChargingStatus = None
        self.chargerStatus = ""
        self.chargerOldStatus = ""
        self.heartbeatInterval = None
        self.heartbeatCnt = 0
        self.meterStart = 0
        self.meterValueInterval = 1  # 서버에서 meterValue 를 1초에 한번씩 보내 달라는 요청이 있음
        self.meterValueCnt = 0
        self.meterValueSendCount = 0
        self.meterStop = 0
        self.modeSelectionFlag = False  # 동양 보드에 필요한 정보
        self.modeSelectionCnt = 0  # modeSelection 을 요청 하여도 상태가 변하지 않을 경우 재 전송을 하기 위한 cnt
        self.faultComment = None
        self.statusComment = None

        self.chargerCardAuthFlag = False
        self.flowInterval = 30  # charging, finish 등 상태를 계속 유지할 경우에 대응 하기 위한 interval
        self.flowCnt = 0

        self.modbus = ModBus485(self.CommPort_MCU, self.BaudRate_MCU)

        self.addrMapFastTypeChargerStatusComment = [
            'Reserved',  # bit15
            'Reserved',  # bit14
            'Reserved',  # bit13
            'Reserved',  # bit12
            '커넥터 잠금',  # bit11
            '커넥터 연결',  # bit10
            '카드 승인',  # bit9
            '카드 등록',  # bit8
            '리셋',  # bit7
            '오류',  # bit6
            '충전 완료',  # bit5
            '충전중',  # bit4
            '카드 승인',  # bit3
            '커넥터 연결',  # bit2
            '충전 가능',  # bit1
            '충전기 준비',  # bit0
        ]

        self.addrMapFastTypeChargerFaultComment = [
            '커넥터 연결',  # 0
            '커넥터 잠금',  # 1
            'Reserved',  # 2
            'Reserved',  # 3
            'Reserved',  # 4
            'Reserved',  # 5
            '카드 승인',  # 6
            '카드 등록',  # 7
            '리셋',  # 8
            '입력 과전류 ',  # 9
            '접지 Fault',  # 10
            'CP Error',  # 11
            'Reserved',  # 12
            '출력 누설/선간절연 이상',  # 13
            '입력 저전압',  # 14
            '입력 과전압'  # 15
        ]

        self.addrMapSlowTypeChargerStatusComment = [
            'Reserved',  # bit15
            'Reserved',  # bit14
            'Reserved',  # bit13
            'Mode Selection(cb)',  # bit12
            'Mode Selection(local)',  # bit11
            'RTU COM CHECK',  # bit10
            '카드 승인',  # bit9
            '카드 등록',  # bit8
            '리셋',  # bit7
            '오류',  # bit6
            '충전 완료',  # bit5
            '충전중',  # bit4
            '카드 승인',  # bit3
            '커넥터 연결',  # bit2
            '충전 가능',  # bit1
            '충전기 준비',  # bit0
        ]

        self.addrMapSlowTypeChargerFaultComment = {
            15: '15:Reserved',
            14: '14:Reserved',
            13: '13:Reserved',
            12: '12:Reserved',
            11: '11:Reserved',
            10: '10:RTU 통신 error',
            9: '9:계량기 Error',
            8: '8:비상 스위치 동작',
            7: '7:Reserved',
            6: '6:입력 과전류 ',
            5: '5:접지 Fault',
            4: '4:CP Error',
            3: '3:Reserved',
            2: '2:출력 누설/선간절연 이상',
            1: '1:입력 저전압',
            0: '0:입력 과전압'
        }

        # Ocpp Data
        self.transactionId = None
        self.idTag = None
        self.price = None

        self.scenarioType = None
        self.acceptAuthOcpp = None
        self.acceptAuthCharger = None
        self.chargingStatus = None
        self.remoteChargingStatus = None
        self.finishStatus = None

        self.bootFlag = False
        self.bootAccept = False
        self.bootRejectCnt = 0
        self.authorizeSendFlag = False
        self.statNotificationFlag = None
        self.statNotificationMessage = None
        self.dataTransSendFlag = False
        self.dataTransAcceptFlag = False
        self.startTransSendFlag = False
        self.startTransactionResult = False
        self.stopTransSendFlag = False
        self.stopTransactionResult = False
        self.blockFlag = False

        self.finishStatus_1_SendFlag = False
        self.finishStatus_2_SendFlag = False

        self.bootNotificationCnt = 0
        self.dataTransCnt = 0
        self.authCnt = 0
        self.startTransCnt = 0
        self.stopTransCnt = 0
        self.stopReason = ""

        self.chargeAmt = 0

        self.setChargerConfiguration()

        self.remoteStartUniqueId = ""
        self.remoteStopUniqueId = ""

        self.finishOk = False
        self.mcuStopSendFlag = False
        self.remoteStop = False

        self.updateFlag = False
        self.updateFailCnt = 0
        self.location = None
        self.retrieveDate = None

        self.fotaStatus = ""
        self.fotaStartFlag = False
        self.firmwareNotiStartFlag = False

        self.sleepInterval = 0.5

        # Test Value
        self.testCnt = 0

    def setWs(self, ws):
        self.ws = ws

    def setModel(self, model):
        self.model = model

    def setPrice(self, price):
        self.price = price

    def getDeviceCode(self):
        return self.deviceCode

    def setAcceptAuthOcpp(self, status):
        self.acceptAuthOcpp = status

    def getStatus(self):
        return self.status

    def setStatus(self, status):
        self.status = status

    def getChargingStatus(self):
        return self.chargingStatus

    def setChargingStatus(self, status):
        self.chargingStatus = status

    def getFinishStatus(self):
        return self.finishStatus

    def setFinishStatus(self, status):
        self.finishStatus = status

    def setHeartbeatInterval(self, interval):
        self.heartbeatInterval = interval

    def setTransactionId(self, transactionId):
        self.transactionId = transactionId

    def setBootAccept(self, flag):
        self.bootAccept = flag

    def getScenarioType(self):
        return self.scenarioType

    def setScenarioType(self, scenarioType):
        self.scenarioType = scenarioType

    def setStatNotificationMessage(self, command):
        self.statNotificationFlag = False
        self.statNotificationMessage = command
        self.deviceOcppOldStatus = self.deviceOcppStatus
        self.deviceOcppStatus = command

    def setDeviceOcppStatus(self, status):
        self.deviceOcppOldStatus = self.deviceOcppStatus
        self.deviceOcppStatus = status

    def getDeviceOcppStatus(self):
        return self.deviceOcppStatus

    def getRemoteChargingStatus(self):
        return self.remoteChargingStatus

    def setRemoteChargingStatus(self, status):
        self.remoteChargingStatus = status

    def setRemoteStartUniqueId(self, uniqueId):
        self.remoteStartUniqueId = uniqueId

    def setRemoteStopUniqueId(self, uniqueId):
        self.remoteStopUniqueId = uniqueId

    def setDataTransAccept(self, result):
        self.dataTransAcceptFlag = result

    def getChargeAMT(self):
        return self.chargeAmt

    def setChargeAmt(self, amt):
        self.chargeAmt = amt

    def setDeviceChargingStatus(self, status):
        self.deviceChargingStatus = status

    def setSleepInterval(self, interval):
        self.sleepInterval = interval

    def bootRejectCntIncrease(self):
        self.bootRejectCnt += 1

    async def getConf(self, uniqueId, key):
        configurationNow = self.conf.getConfigurationByKey(key)
        # if key == "All":
        #     configurationNow = self.conf.getConfigurationAll()
        # else:
        #     configurationNow = self.conf.getConfigurationByKey(key)

        resultKey = configurationNow.key
        resultReadOnly = configurationNow.write_accessibility
        resultValue = configurationNow.value

        getConfiguration_res_payload = GetConfigurationResPayload(
            key=resultKey,
            readonly=resultReadOnly,
            value=resultValue
        )
        getConfiguration_result = CallResult(uniqueId, getConfiguration_res_payload.json)

        await self.ws.requestAction(getConfiguration_result.message)

    async def setConf(self, uniqueId, key, value):
        changeConfiguration_res_payload = None
        result = self.conf.setConfiguration(key, value)
        if result == ConfigurationStatus.Accepted.name:
            changeConfiguration_res_payload = ChangeConfigurationResPayload(
                status=ConfigurationStatus.Accepted.name
            )
        if result == ConfigurationStatus.Rejected.name:
            changeConfiguration_res_payload = ChangeConfigurationResPayload(
                status=ConfigurationStatus.Rejected.name
            )
        if result == ConfigurationStatus.NotSupported.name:
            changeConfiguration_res_payload = ChangeConfigurationResPayload(
                status=ConfigurationStatus.NotSupported.name
            )
        changeConfiguration_result = CallResult(uniqueId, changeConfiguration_res_payload.json)

        await self.ws.requestAction(changeConfiguration_result.message)

    def setChargerConfiguration(self):
        result = self.conf.getConfigurationAll()

        self.heartbeatInterval = int(result["HeartbeatInterval"].value)
        self.flowInterval = int(result["ConnectionTimeOut"].value)
        self.meterValueInterval = int(result["MeterValueSampleInterval"].value)

    def getFaultList(self):
        fault = self.data["fault"]
        faultList = []
        for num in range(0, 16):
            if fault[num] == "1":
                faultList.append(num)
        return faultList

    def setIdTag(self, idTag):
        self.idTag = idTag

    def setStartTransactionResult(self, result):
        self.startTransactionResult = result

    def getStatusAndErrorCode(self):
        status = ""
        errorCode = ChargePointErrorCode.NoError.name
        vendorErrorCode = ""
        notificationMessage = self.statNotificationMessage

        if notificationMessage == NotificationStatus.Ready.name:
            status = ChargePointStatus.Available.name
        elif notificationMessage == NotificationStatus.Charging.name:
            status = ChargePointStatus.Charging.name
        elif notificationMessage == NotificationStatus.Finish.name:
            status = ChargePointStatus.Finishing.name
        elif notificationMessage == NotificationStatus.Preparing.name:
            status = ChargePointStatus.Preparing.name
        elif notificationMessage == NotificationStatus.Unavailable.name:
            status = ChargePointStatus.Unavailable.name

        elif notificationMessage == NotificationStatus.Fault.name and self.data['fault'] != "0000000000000000":
            faultList = self.getFaultList()
            faultNow = self.data['fault']
            faultCode = -1

            if len(faultList) != 0:
                if 5 in faultList:
                    print(faultNow[5])  # RTU 통신 Fault
                    errorCode = ChargePointErrorCode.OtherError.name
                    faultCode = 10
                if 6 in faultList:
                    print(faultNow[6])  # 계량기 Fault
                    errorCode = ChargePointErrorCode.OtherError.name
                    faultCode = 9
                if 7 in faultList:
                    print(faultNow[7])  # 비상 스위치 Fault
                    errorCode = ChargePointErrorCode.OtherError.name
                    faultCode = 8
                if 9 in faultList:
                    print(faultNow[9])  # Over Current Fault
                    errorCode = ChargePointErrorCode.OverCurrentFailure.name
                    faultCode = 6
                if 10 in faultList:
                    print(faultNow[10])  # Ground Fault
                    errorCode = ChargePointErrorCode.GroundFailure.name
                    faultCode = 5
                if 11 in faultList:
                    print(faultNow[11])  # CP Error
                    errorCode = ChargePointErrorCode.OtherError.name
                    faultCode = 4
                if 13 in faultList:
                    print(faultNow[13])  # 선간 절연
                    errorCode = ChargePointErrorCode.GroundFailure.name
                    faultCode = 2
                if 14 in faultList:
                    print(faultNow[14])  # Under Voltage
                    errorCode = ChargePointErrorCode.UnderVoltage.name
                    faultCode = 1
                if 15 in faultList:
                    print(faultNow[15])  # Over Voltage
                    errorCode = ChargePointErrorCode.OverVoltage.name
                    faultCode = 0

                vendorErrorCode = self.addrMapSlowTypeChargerFaultComment[faultCode]
                status = ChargePointStatus.Faulted.name

        return status, errorCode, vendorErrorCode

    async def isTransactionId(self, uniqueId, stopTransactionId):
        try:
            chargingStatus = self.getChargingStatus()
            if self.transactionId == stopTransactionId and chargingStatus == ChargerActiveStatus.MeterValue.name:
                remoteStopTransaction_res_payload = RemoteStopTransactionResPayload(
                    status=RemoteStartStopStatus.Accepted.name,
                )
                remoteStopTransaction_call = CallResult(uniqueId, remoteStopTransaction_res_payload.json)
                await self.ws.remoteResult(remoteStopTransaction_call.message)
                self.setRemoteStopUniqueId(uniqueId)
                self.stopReason = Reason.Remote.name
                return True
            else:
                remoteStopTransaction_res_payload = RemoteStopTransactionResPayload(
                    status=RemoteStartStopStatus.Rejected.name,
                )
                remoteStopTransaction_call = CallResult(uniqueId, remoteStopTransaction_res_payload.json)
                await self.ws.remoteResult(remoteStopTransaction_call.message)
                return False
        except Exception as e:
            print("isTransactionId")
            print(e)
            raise e

    async def remoteStartResult(self, uniqueId, flag):
        try:
            status = RemoteStartStopStatus.Accepted.name
            if flag is False:
                status = RemoteStartStopStatus.Rejected.name
            remoteStartTransaction_res_payload = RemoteStartTransactionResPayload(
                status=status
            )
            remoteStopTransaction_call = CallResult(uniqueId, remoteStartTransaction_res_payload.json)
            await self.ws.remoteResult(remoteStopTransaction_call.message)
            self.setRemoteStartUniqueId(uniqueId)
        except Exception as e:
            print("remoteStartStopResult")
            print(e)
            raise e

    async def notSupportedAction(self, uniqueId, action):
        if action == Action.Reset.name:
            status = ResetStatus.Rejected.name
            reset_res_payload = ResetResPayload(status=status)
            reset_call = CallResult(uniqueId, reset_res_payload.json)
            await self.ws.remoteResult(reset_call.message)
        elif action == Action.ChangeAvailability.name:
            status = AvailabilityStatus.Rejected.name
            changeAvailability_res_payload = AuthorizeReqPayload(status=status)
            changeAvailability_call = CallResult(uniqueId, changeAvailability_res_payload.json)
            await self.ws.remoteResult(changeAvailability_call.message)
        elif action == Action.UnlockConnector.name:
            status = UnlockStatus.NotSupported.name
            unlockConnector_res_payload = UnlockConnectorResPayload(status=status)
            unlockConnector_call = CallResult(uniqueId, unlockConnector_res_payload.json)
            await self.ws.remoteResult(unlockConnector_call.message)

    def getInt16(self, buff, offset):
        try:
            tempData = buff[offset]
            tempData <<= 8
            tdLow = buff[offset + 1]
            tempData |= tdLow
            return tempData
        except IndexError as e:
            return 0

    def getInt32(self, buff, offset):
        try:
            tempData = buff[offset]
            tempData <<= 8
            tdLow = buff[offset + 1]
            tempData |= tdLow
            tempData <<= 8
            tdLow = buff[offset + 2]
            tempData |= tdLow
            tempData <<= 8
            tdLow = buff[offset + 3]
            tempData |= tdLow

            return tempData
        except IndexError as e:
            return 0

    def getCardNum(self, buff, offset):
        try:
            # 티머니 베이스
            cardNum = format(buff[offset], '02x').zfill(2)
            cardNum += format(buff[offset + 1], '02x').zfill(2)
            cardNum += format(buff[offset + 2], '02x').zfill(2)
            cardNum += format(buff[offset + 3], '02x').zfill(2)
            cardNum += format(buff[offset + 4], '02x').zfill(2)
            cardNum += format(buff[offset + 5], '02x').zfill(2)
            cardNum += format(buff[offset + 6], '02x').zfill(2)
            cardNum += format(buff[offset + 7], '02x').zfill(2)

            print("티머니 베이스 데이터 : ", cardNum)

            # 동양 베이스
            tempData = buff[offset]
            tempData <<= 8
            tdLow = buff[offset + 1]
            tempData |= tdLow
            tempData <<= 8
            tdLow = buff[offset + 2]
            tempData |= tdLow
            tempData <<= 8
            tdLow = buff[offset + 3]
            tempData |= tdLow

            tdLow = buff[offset + 4]
            tempData |= tdLow
            tempData <<= 8
            tdLow = buff[offset + 5]
            tempData |= tdLow
            tempData <<= 8
            tdLow = buff[offset + 6]
            tempData |= tdLow
            tempData <<= 8
            tdLow = buff[offset + 7]
            tempData |= tdLow

            print("동양 베이스 데이터 : ", tempData)

            return cardNum
        except IndexError as e:
            return 0

    def getFloat(self, buff, offset):
        try:
            tempData = u_type()
            tempData.chunk[0] = buff[offset + 3]
            tempData.chunk[1] = buff[offset + 2]
            tempData.chunk[2] = buff[offset + 1]
            tempData.chunk[3] = buff[offset]

            return tempData.data
        except IndexError as e:
            return 0

    def getMcuData(self, deviceId, startAddr, dataCount):
        try:
            return self.modbus.ReadMCU(deviceId, startAddr, dataCount)
        except Exception as e:
            print("getMcuData Error : ", e)
            raise e

    def setMcuAmountData(self, amt):
        nowAmt = format(amt, '08x')
        upperAmt = int(nowAmt[:4], 16)
        lowerAmt = int(nowAmt[4:], 16)

        self.writeMcuData(
            self.deviceId,
            self.modbusWriteAddr["amount"],
            [upperAmt, lowerAmt]
        )

    def writeMcuData(self, device_id, addr, data: list[int]):
        try:
            length = len(data)
            dataCount = 2 * length
            return self.modbus.WriteMCU(device_id, addr, dataCount, data)
        except Exception as e:
            print("writeMcuData Error : ", e)
            raise e

    def slowTypeDataMapping(self, array):
        length = len(array)
        if not array:
            print("dataMapping fault")
            print(array)
            self.CommErr += 1
            if self.CommErr > 5:
                self.setStatus(ChargerStatus.Comm_fault.name)
        else:
            self.CommErr = 0
            # 400 Charger Status
            readData = {}
            mcuStatus = self.getInt16(array, 0)
            bits = format(mcuStatus, '0>16b')
            bitLength = len(bits)
            statusComment = ""
            for i in range(bitLength):
                if bits[i] == "1":
                    if statusComment == "":
                        statusComment = self.addrMapSlowTypeChargerFaultComment[i]
                    else:
                        statusComment = statusComment + ", " + self.addrMapSlowTypeChargerFaultComment[i]
            readData['status'] = bits
            self.statusComment = statusComment
            self.chargerOldStatus = self.chargerStatus
            self.chargerStatus = bits

            # 401 충전기/계량기 버전
            chargerVersion = float(self.getInt16(array, 2))
            readData['chargerVersion'] = round(chargerVersion / 100, 2)

            # 402 Run Count
            runCount = self.getInt16(array, 4)
            self.runCnt_HI = array[4]
            self.runCnt_LO = array[5]
            readData['runCount'] = runCount
            # print("runCount : " + str(self.data['runCount']))

            # 403~406 Card Number
            tstr = self.getCardNum(array, 6)  # 16 BYTE 적용 필요
            readData['cardNum'] = tstr
            # if array[6] != 0:
            #     print(array[6:14])
            # print("cardNum : " + str(self.data['cardNum']))

            # 407~408 전력량계 누적전력
            tstr = self.getInt32(array, 14)
            # 전력량계의 기본값이 10 W 이므로 10 으로 곱해 1 W 단위로 바꾼다
            readData['totalPower'] = tstr * 10
            # print("totalPower : " + str(self.data['totalPower']))

            # 409 Now Power
            tstr = self.getInt16(array, 18)
            readData['powerNow'] = tstr
            # print("powerNow : " + str(self.data['powerNow']))

            # 410 Output Voltage
            tstr = float(self.getInt16(array, 20))
            readData['outputVoltage'] = round(tstr / 10, 1)
            # print("voltageNow : " + str(self.data['voltageNow']))

            # 411 Output Current
            tstr = float(self.getInt16(array, 22))
            readData['outputCurrent'] = round(tstr / 10, 1)
            # print("currentNow : " + str(self.data['currentNow']))

            # 412 Fault
            fault = self.getInt16(array, 24)
            # print("faultCode : " + str(self.data['faultCode']))

            bits = format(fault, '0>16b')
            faultComment = None
            for i in range(bitLength):
                if bits[i] == 1:
                    if faultComment is None:
                        faultComment = self.addrMapSlowTypeChargerStatusComment[i]
                    else:
                        faultComment = faultComment + "," + self.addrMapSlowTypeChargerStatusComment[i]
            readData['fault'] = bits
            self.faultComment = faultComment

            # 충전기 번호
            tstr = self.getInt16(array, 26)
            readData['serialNumber'] = tstr

            # 충전 누적 전력
            tstr = self.getInt16(array, 30)
            readData['chargingTotalPower'] = round(tstr, 2)

            readData['SOC'] = 0
            readData['running_time'] = 0
            readData['targetVoltage'] = 0
            readData['targetCurrent'] = 0
            readData['firmwareVersion'] = 0
            readData['manufacturerOption'] = 0
            readData['connectorBoxInfo'] = 0

            self.oldData = self.data
            self.data = readData

    async def insertDataToDB(self, insertData):
        charger = self.model(
            charger_status=str(insertData["status"]),
            charger_version=insertData["chargerVersion"],
            run_count=insertData["runCount"],
            card_number=insertData["cardNum"],
            total_power=insertData["totalPower"],
            power_now=insertData["powerNow"],
            output_voltage=insertData["outputVoltage"],
            output_current=insertData["outputCurrent"],
            SOC=insertData["SOC"],
            running_time=insertData["running_time"],
            target_voltage=insertData["targetVoltage"],
            target_current=insertData["targetCurrent"],
            version=insertData["firmwareVersion"],
            fault=insertData["fault"],
            charger_serial_number=insertData["serialNumber"],
            charging_power=insertData["chargingTotalPower"],
            manufacturer_option=insertData["manufacturerOption"],
            connector_box_info=insertData["connectorBoxInfo"],
        )
        charger.save()

    def checkChangeStatus(self):
        old = self.chargerOldStatus
        new = self.chargerStatus
        if len(old) == 0:
            return

        # 충전기 준비
        if self.status is None and new[15] == "1":
            self.setStatus(ChargerStatus.Init.name)

        # 카드 태깅 후 커넥터 연결 상태 체크
        if self.chargingStatus == ChargerActiveStatus.PlugCheck.name and new[13] == "1":
            self.connectorStatus = True
            self.setChargingStatus(ChargerActiveStatus.StartTransaction.name)

        # 충전 완료 후 커넥터의 연결이 햬제 되었는지에 대한 플래그
        if self.finishStatus == ChargerActiveStatus.FinishStatus_2 and new[13] == "0":
            self.connectorStatus = False

        # 카드 태깅
        if self.status == ChargerStatus.Ready.name and new[12] == "1" and old[12] != new[12]:
            self.setStatus(ChargerStatus.Tagging.name)

        elif self.status == ChargerStatus.Charging.name and new[12] == "1" and old[12] != new[12]:
            if str(self.data['cardNum']) == self.idTag:
                self.finishOk = True
                # self.setStatus(ChargerStatus.Finish.name)
                # self.setFinishStatus(ChargerActiveStatus.Stop.name)
                # self.setDeviceChargingStatus("Finish")
            else:
                print("ID Tag Not Matched.... charging progress")

        # 카드 태깅이 된 후 동작이 없을 경우 Ready 상태로 초기화 하기 위한 코드
        elif self.status == ChargerStatus.Ready.name and new[12] == "1" and old[12] == new[12]:
            self.setStatus(ChargerStatus.Block.name)

        if self.status == ChargerStatus.Block.name and new[12] == "0" and old[12] != new[12]:
            self.setStatus(ChargerStatus.InitializeData.name)

        # 충전 완료
        if self.getChargingStatus() == ChargerActiveStatus.MeterValue.name and \
                self.getStatus() == ChargerStatus.Charging.name and self.remoteStop is False:

            # 원격 시작 후 카드 태깅 정지 할 경우에 대응하는 로직
            if self.oldData['cardNum'] != self.data['cardNum']:
                print("old Card Number : " + self.oldData['cardNum'])
                print("new Card Number : " + self.data['cardNum'])
                if self.idTag == self.data['cardNum']:
                    print("card Number Matched")
                    self.finishOk = True
                    self.stopReason = Reason.Local.name
                else:
                    print("card Number Not Matched")

            if new[9] == "1":  # status : Fault
                self.finishOk = True
                self.stopReason = Reason.EmergencyStop.name
            # 충전중 커넥터가 연결해제 될 경우에 대응하는 로직
            elif new[13] == "0" and old[13] != new[13]:  # status : Connector disconnection
                print("connector disconnection")
                self.finishOk = True
                self.stopReason = Reason.EVDisconnected.name

            elif new[10] == "1" and old[10] != new[10]:  # status : 충전 완료
                self.finishOk = True
                self.stopReason = Reason.Local.name

            # 충전 완료 상태가 1로 변하지 않고 꺼지는 경우에 대한 추가 로직
            elif new[11] == "0" and old[11] != new[11]:  # status : 충전중 -> 충전중이 아님
                print("충전 완료 후 충전완료 플래그가 올라오지 않음")
                self.finishOk = True
                self.stopReason = Reason.Local.name

        # 충전 시작
        if self.status == ChargerStatus.Charging.name and new[11] == "1" and old[11] != new[11]:
            self.setDeviceChargingStatus("Charging")

        # Fault 상태
        if new[9] == "1" and old[9] != new[9] and self.data['fault'] != "0000000000000000":
            self.setDeviceOcppStatus(NotificationStatus.Fault.name)

        # Fault 상태에서 정상으로 돌아온 경우
        if new[9] == "0" and old[9] != new[9] and self.deviceOcppStatus == ChargerStatus.Fault.name:
            self.setStatus(ChargerStatus.InitializeData.name)
            # self.setStatNotificationMessage(NotificationStatus.Ready.name)

        # Authorize 인증 후 보드에 카드 인증 Write 후 상태변경 check
        if self.status == ChargerStatus.Authorize.name and new[6] == "1":
            self.acceptAuthCharger = "Accepted"

        # Mode Selection 이 Local 인 경우 CB 모드로 변환
        if new[3] != "1" and self.modeSelectionFlag is False and self.chargerMode == "CB":
            self.writeMcuData(
                self.deviceId,
                self.modbusWriteAddr["status"],
                [self.modbusStatusWriteValue["mode_cb"]]
            )
            self.modeSelectionFlag = True
            self.modeSelectionCnt = 0

        # Mode Selection Write 후 상태가 변경되지 않을 경우 다시 Write
        if new[4] != "1" and self.modeSelectionFlag is True:
            self.modeSelectionCnt += 1
            if self.modeSelectionCnt > 5:
                self.modeSelectionFlag = False

    async def updateFirmware(self, path):
        try:
            isFile = os.path.isfile(path)

            if isFile:
                await asyncio.create_subprocess_exec(path)

            return True
        except Exception as e:
            print("updateFirmware Function")
            print(e)
            return False

    async def updateFirmwareResponse(self, uniqueId, location, retrieveDate):
        self.location = location
        self.retrieveDate = retrieveDate

        resultMsg = {}
        updateFirmwareResponse_call = CallResult(uniqueId, resultMsg)

        self.updateFlag = True

        print(updateFirmwareResponse_call.message)

        await self.ws.remoteResult(updateFirmwareResponse_call.message)

    async def updateFinishSeq(self):
        path = "../source_update.sh"
        try:
            os.system(path)
        except Exception as e:
            print("source Update Failed")
            print(e)
            return False
        finally:
            await asyncio.sleep(5)
            print("sudo reboot")
            os.system("sudo reboot")

    async def start(self):
        if TEST_START_LOGIC is None and self.getStatus() != ChargerStatus.Update.name:
            try:
                response = self.getMcuData(1, self.baseAddr_Read, 16)

            except Exception as e:
                print(e)
                raise e
            if response is not None:
                self.slowTypeDataMapping(response)

                print(self.data)
                ss = self.data["status"]
                print("status : ", self.status)
                print("충전기 Ready", ss[15])
                print("충전 Ready", ss[14])
                print("플러그", ss[13])
                print("카드 태깅", ss[12])
                print("충전 시작", ss[11])
                print("충전 끝", ss[10])
                print("폴트", ss[9])
                # print("리셋", ss[8])
                print("카드 등록", ss[7])
                print("카드 승인", ss[6])
                # print("모드 low bit", ss[5])
                # print("모드 high bit", ss[4])
                if DEBUG_LOGGING:
                    self.logger_MCU.debug("-----------------")
                    self.logger_MCU.debug("data : " + str(self.data))
                    if self.status is None:
                        self.logger_MCU.debug("status : None")
                    else:
                        self.logger_MCU.debug("status : " + self.status)
                        self.logger_MCU.debug("충전기 Ready : " + ss[15])
                        self.logger_MCU.debug("충전 Ready : " + ss[14])
                        self.logger_MCU.debug("플러그 : " + ss[13])
                        self.logger_MCU.debug("카드 태깅 : " + ss[12])
                        self.logger_MCU.debug("충전 시작 : " + ss[11])
                        self.logger_MCU.debug("충전 끝 : " + ss[10])
                        self.logger_MCU.debug("폴트 : " + ss[9])
                        self.logger_MCU.debug("리셋 : " + ss[8])
                        self.logger_MCU.debug("카드 등록 : " + ss[7])
                        self.logger_MCU.debug("카드 승인 : " + ss[6])
                        self.logger_MCU.debug("모드 low bit : " + ss[5])
                        self.logger_MCU.debug("모드 high bit : " + ss[4])

                if self.data != {}:
                    await self.insertDataToDB(self.data)

                # 변하는 status 확인
                self.checkChangeStatus()

        if TEST_START_LOGIC == "startTest":
            await self.startTestLogic()

        if self.status == ChargerStatus.Init.name:
            self.bootNotificationCnt += 1

            if self.bootRejectCnt >= 5:
                print("서버에서 bootNotification 응답이 없습니다.")

            if self.bootNotificationCnt >= 5:
                self.bootNotificationCnt = 0
                self.bootFlag = False

            if self.bootFlag is False:
                try:
                    bootNotification_req_payload = BootNotificationReqPayload(
                        chargePointModel=self.modelName,
                        chargePointVendor=self.vendorName,
                    )
                    bootNotification_call = Call(Action.BootNotification.name, bootNotification_req_payload.json)
                    self.bootFlag = True
                    await self.ws.requestAction(bootNotification_call.message)
                    print("bootNotification")
                except Exception as e:
                    raise e
            if self.bootAccept is True:
                self.flowCnt = 0
                self.bootRejectCnt = 0
                self.setStatus(ChargerStatus.InitializeData.name)
                print("bootAccept")

        elif self.status == ChargerStatus.InitializeData.name:
            # finish
            self.transactionId = None
            self.meterStart = 0
            self.meterStop = 0
            self.idTag = None
            self.setDeviceChargingStatus(None)
            self.startTransactionResult = False
            self.chargingStatus = None
            self.finishStatus = None
            self.setScenarioType(None)
            self.authorizeSendFlag = False
            self.meterValueCnt = 0
            self.startTransSendFlag = False
            self.stopTransSendFlag = False
            self.stopReason = ""
            self.finishStatus_1_SendFlag = False
            self.finishStatus_2_SendFlag = False
            self.flowCnt = 0
            self.setChargeAmt(0)
            self.setPrice(0)
            self.finishOk = False
            self.remoteStop = False
            self.mcuStopSendFlag = False

            self.meterValueSendCount = 0

            # ChargerStatus.Charging.name and chargingStatus is None
            self.chargerCardAuthFlag = False
            self.acceptAuthOcpp = None
            self.acceptAuthCharger = None

            # dataTransAcceptFlag
            self.dataTransSendFlag = False
            self.dataTransAcceptFlag = False
            self.flowCnt = 0

            # blockFlag
            self.blockFlag = False

            self.setStatus(ChargerStatus.Ready.name)
            self.setStatNotificationMessage(NotificationStatus.Ready.name)

        elif self.status == ChargerStatus.Ready.name:
            self.bootFlag = False
            self.bootAccept = False

            if self.updateFlag is True:
                self.setStatus(ChargerStatus.Update.name)

        elif self.status == ChargerStatus.Tagging.name:
            print("card tagging")
            if self.getScenarioType() == ScenarioType.Remote.name:
                self.setStatus(ChargerStatus.Authorize.name)
                self.setDeviceChargingStatus("Charging")
            else:
                self.setScenarioType(ScenarioType.Card_Tagging.name)
                self.idTag = str(self.data["cardNum"])
                self.setChargeAmt(30000)
                self.setStatus(ChargerStatus.Authorize.name)

        elif self.status == ChargerStatus.RemoteStart.name:
            self.setStatus(ChargerStatus.Authorize.name)
            self.setDeviceChargingStatus("Charging")

        elif self.status == ChargerStatus.Authorize.name:
            print("authorize")
            if self.authorizeSendFlag is False:
                authorize_req_payload = AuthorizeReqPayload(idTag=self.idTag)
                authorize_call = Call(Action.Authorize.name, authorize_req_payload.json)
                await self.ws.requestAction(authorize_call.message)
                self.authorizeSendFlag = True

            if self.acceptAuthOcpp == "Accepted":
                self.setStatus(ChargerStatus.Charging.name)
                self.setStatNotificationMessage(NotificationStatus.Preparing.name)
                self.flowCnt = 0

        elif self.status == ChargerStatus.Charging.name:
            if self.chargingStatus is None:
                self.chargerCardAuthFlag = False
                self.acceptAuthOcpp = None
                self.acceptAuthCharger = None
                self.flowCnt = 0

            if self.chargingStatus == ChargerActiveStatus.REQ_PRICE.name:
                if self.dataTransSendFlag is False:
                    request_price = ReqPrice(connectorId=str(self.connectorId), idTag=self.idTag)
                    req_price = DataTransferReqPayload(
                        vendorId=self.vendorName,
                        messageId=CrocusDataTransferMessageId.REQ_PRICE.name,
                        data=request_price.json
                    )
                    req_price_call = Call(Action.DataTransfer.name, req_price.json)
                    await self.ws.requestAction(req_price_call.message)

                    print("dataTransfer")
                    self.dataTransSendFlag = True
                if self.dataTransAcceptFlag is True:
                    self.setChargingStatus(ChargerActiveStatus.REQ_CHARGE_AMT.name)
                    self.dataTransSendFlag = False
                    self.dataTransAcceptFlag = False
                    self.flowCnt = 0

            if self.chargingStatus == ChargerActiveStatus.REQ_CHARGE_AMT.name:
                if self.dataTransSendFlag is False:
                    request_charge_amount = ReqChargeAmt(
                        connectorId=str(self.connectorId),
                        chargereqAmt=self.chargeAmt,
                        idTag=self.idTag
                    )
                    charge_amt = DataTransferReqPayload(
                        vendorId=self.vendorName,
                        messageId=CrocusDataTransferMessageId.REQ_CHARGE_AMT.name,
                        data=request_charge_amount.json
                    )
                    req_price_call = Call(Action.DataTransfer.name, charge_amt.json)
                    await self.ws.requestAction(req_price_call.message)
                    print("dataTransfer")
                    self.dataTransSendFlag = True
                if self.dataTransAcceptFlag is True:
                    self.setChargingStatus(ChargerActiveStatus.PlugCheck.name)
                    self.dataTransSendFlag = False
                    self.dataTransAcceptFlag = False
                    self.flowCnt = 0

            if self.chargingStatus == ChargerActiveStatus.PlugCheck.name:
                print("plugCheck")

            if self.chargingStatus == ChargerActiveStatus.StartTransaction.name:
                if self.startTransSendFlag is False:
                    self.meterStart = math.trunc(self.data["totalPower"])
                    startTransaction_req_payload = StartTransactionReqPayload(
                        connectorId=self.connectorId,
                        idTag=self.idTag,
                        meterStart=self.meterStart,  # kWh 단위를 Wh 단위로 변경
                        timestamp=str(datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"))
                    )
                    startTransaction_call = Call(Action.StartTransaction.name, startTransaction_req_payload.json)
                    await self.ws.requestAction(startTransaction_call.message)
                    self.startTransSendFlag = True
                    self.flowCnt = 0

                if self.startTransactionResult is True:
                    if self.chargerCardAuthFlag is False:

                        writeValue = self.modbusStatusWriteValue["card_authorize"]
                        if self.chargerMode == "CB":
                            writeValue += self.modbusStatusWriteValue["mode_cb"]
                        if self.chargerMode == "Local":
                            writeValue += self.modbusStatusWriteValue["mode_local"]

                        writeData = self.writeMcuData(
                            self.deviceId,
                            self.modbusWriteAddr["status"],
                            [writeValue]
                        )
                        print(writeData)
                        self.chargerCardAuthFlag = True
                        if DEBUG_LOGGING:
                            self.logger_MCU.debug("Authorize : " + str(writeData))

                        # 소수점까지의 데이터를 입력해주기 위해 * 100 을 한다(ex. 1234 write = mcu 12.34 출력)
                        self.setMcuAmountData(self.price * 100)

                    if self.deviceChargingStatus == "Charging":
                        self.setChargingStatus(ChargerActiveStatus.MeterValue.name)
                        self.setStatNotificationMessage(NotificationStatus.Charging.name)

                print("startTransaction")

            if self.chargingStatus == ChargerActiveStatus.MeterValue.name:
                self.meterValueCnt += 1

                if self.meterValueInterval is not None:
                    if self.meterValueCnt > self.meterValueInterval:
                        sample_value = SampledValue(
                            value=math.trunc(self.data['totalPower']),  # kWh 단위를 Wh 단위로 변경
                            context=ReadingContext.Transaction_Begin.name,
                            format=ValueFormat.Raw.name,
                            measurand=Measurand.Power_Active_Export.value,
                            location=Location.Outlet.name,
                            unit=UnitOfMeasure.Wh.name
                        )

                        meter_value = MeterValue(timestamp=str(datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")),
                                                 sampledValue=[sample_value.json])

                        meterValue_req_payload = MeterValueReqPayload(
                            connectorId=self.connectorId,
                            transactionId=self.transactionId,
                            meterValue=[meter_value.json]
                        )

                        meterValue_call = Call(Action.MeterValues.name, meterValue_req_payload.json)

                        await self.ws.requestAction(meterValue_call.message)

                        self.meterValueCnt = 0
                        self.meterValueSendCount += 1
                        if self.meterValueSendCount == 30:
                            self.meterValueInterval = 20

                nowChargingPower = int(self.data['totalPower']) - self.meterStart
                nowAmt = round((nowChargingPower * 0.001) * self.price)

                if nowAmt >= self.getChargeAMT() or self.finishOk is True:
                    self.setStatus(ChargerStatus.Finish.name)
                    self.setFinishStatus(ChargerActiveStatus.Stop.name)
                    self.setDeviceChargingStatus("Finish")

                setIntervalValue = self.getChargeAMT() - (self.price * 3)

                # 충전이 완료 되기 전에 다시 meterValueInterval을 1초로 바꾸는 로직
                if setIntervalValue <= nowAmt:
                    self.meterValueInterval = 1

        elif self.status == ChargerStatus.Finish.name:
            print(self.finishStatus)
            if self.finishStatus == ChargerActiveStatus.Stop.name:
                self.setChargingStatus(None)
                writeValue = self.modbusStatusWriteValue["finish"]
                if self.chargerMode == "CB":
                    writeValue += self.modbusStatusWriteValue["mode_cb"]
                if self.chargerMode == "Local":
                    writeValue += self.modbusStatusWriteValue["mode_local"]

                self.writeMcuData(
                    self.deviceId,
                    self.modbusWriteAddr["status"],
                    [writeValue]
                )
                self.mcuStopSendFlag = True

                if self.remoteStop is True:
                    self.setFinishStatus(ChargerActiveStatus.RemoteStopTransaction.name)
                else:
                    self.setFinishStatus(ChargerActiveStatus.StopTransaction.name)

            if self.finishStatus == ChargerActiveStatus.RemoteStopTransaction.name:
                targetRow = self.ws.model.select().where(self.ws.model.unique_id == self.remoteStopUniqueId)
                resPayload = eval(targetRow[0].response_payload)

                if resPayload[0] == 3:
                    print("remoteStopTransaction Response Ok")
                    self.setFinishStatus(ChargerActiveStatus.StopTransaction.name)
                    self.setDeviceChargingStatus("Finish")
                elif resPayload[0] == 4:
                    print("remoteStartTransaction Response Fail")
                    self.setStatus(ChargerStatus.Block.name)

            if self.finishStatus == ChargerActiveStatus.StopTransaction.name:
                if self.deviceChargingStatus == "Finish":
                    if self.stopTransSendFlag is False:
                        sample_value = SampledValue(value=self.data['totalPower'], format=ValueFormat.Raw.name)
                        meter_value = MeterValue(timestamp=str(datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")),
                                                 sampledValue=[sample_value.json])

                        self.meterStop = math.trunc(self.data["totalPower"])
                        stopTransaction_req_payload = StopTransactionReqPayload(
                            idTag=self.idTag,
                            meterStop=self.meterStop,  # kWh 단위를 Wh 단위로 변경
                            timestamp=str(datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")),
                            transactionId=self.transactionId,
                            transactionData=[meter_value.json],
                            reason=self.stopReason
                        )

                        stopTransaction_call = Call(Action.StopTransaction.name, stopTransaction_req_payload.json)

                        await self.ws.requestAction(stopTransaction_call.message)
                        self.stopTransSendFlag = True
                if self.getDeviceOcppStatus() == ChargerStatus.Fault.name:
                    self.setStatNotificationMessage(NotificationStatus.Fault.name)

            if self.finishStatus == ChargerActiveStatus.FinishStatus_1.name:
                if self.finishStatus_1_SendFlag is False:
                    self.setStatNotificationMessage(NotificationStatus.Finish.name)
                    self.finishStatus_1_SendFlag = True

            if self.finishStatus == ChargerActiveStatus.FinishStatus_2.name:
                print("connector Check")
                if self.connectorStatus is False:
                    self.setFinishStatus(ChargerActiveStatus.Finish.name)

            if self.finishStatus == ChargerActiveStatus.Finish.name:
                self.setStatus(ChargerStatus.InitializeData.name)

            print("finish")

        elif self.status == ChargerStatus.Block.name:
            print("Status = Block")
            if self.blockFlag is False:
                writeValue = self.modbusStatusWriteValue["authorize_fail"]
                if self.chargerMode == "CB":
                    writeValue += self.modbusStatusWriteValue["mode_cb"]
                if self.chargerMode == "Local":
                    writeValue += self.modbusStatusWriteValue["mode_local"]

                self.writeMcuData(
                    1,
                    self.modbusWriteAddr["status"],
                    [writeValue]
                )
                self.blockFlag = True

                self.setStatus(ChargerStatus.InitializeData.name)

        elif self.status == ChargerStatus.Fault.name:
            print("fault")

        elif self.status == ChargerStatus.Comm_fault.name:
            self.setStatNotificationMessage(NotificationStatus.Comm_fault.name)
            print("comm_fault")

        elif self.status == ChargerStatus.Update.name:
            print("update")

            dfuListPath = "../../dfu_list"
            dfuConfigPath = "../../run_dfu_log"
            configJsonFilePath = "../../dfu_config.json"
            dufCfgDefaultPath = "../../dfu_cfg_default"

            if self.fotaStartFlag is False:
                self.modbus.Disconnect()

                self.retrieveDate = datetime.utcnow().strftime("%Y-%m-%d %H:%M")

                firmwareLocation = self.location.replace(" ", "")

                if self.location[-1] == "/":
                    writeData = firmwareLocation + "dfu_list\n"
                    writeData += firmwareLocation + "dfu_config.json"
                else:
                    writeData = firmwareLocation + "/dfu_list\n"
                    writeData += firmwareLocation + "/dfu_config.json"

                with open(dufCfgDefaultPath, "w") as f:
                    f.write(writeData)
                    f.close()

                self.fotaStartFlag = True

                isFile = os.path.isfile(configJsonFilePath)

                if isFile:
                    with open(configJsonFilePath, 'r') as f:
                        jsonData = json.load(f)
                        jsonData['fota_status'] = 'Idle'
                    with open(configJsonFilePath, 'w') as json_file:
                        json.dump(jsonData, json_file)

                await self.updateFirmware(dfuConfigPath)

                self.setSleepInterval(3)

                self.setStatNotificationMessage(NotificationStatus.Unavailable.name)

            with open(configJsonFilePath, "r") as f:
                logData = json.load(f)
                fota = logData["fota_status"]

                if fota == "cron.daily":
                    self.updateFailCnt += 1
                    if self.updateFailCnt == 1:
                        print("Update Failed : 10초 후 정상 상태로 복귀")
                        print("cron Job 등록 완료 정시에 업데이트 재시도 예정")

                    if self.updateFailCnt > 10:
                        await self.updateFinishSeq()

                if fota == "Idle" and self.firmwareNotiStartFlag is False:
                    self.firmwareNotiStartFlag = True

                if self.fotaStatus != fota and self.firmwareNotiStartFlag is True:
                    firmwareStatusNotification_req_payload = FirmwareStatusNotificationReqPayload(
                        status=fota
                    )
                    firmwareStatusNotification_call = Call(Action.FirmwareStatusNotification.name,
                                                           firmwareStatusNotification_req_payload.json)
                    await self.ws.requestAction(firmwareStatusNotification_call.message)
                    self.fotaStatus = fota

                    if self.fotaStatus == "Installed":
                        await self.updateFinishSeq()

                # 펌웨어 업데이트 실패 하였을 경우의 대한 처리
                if "Failed" in self.fotaStatus:
                    self.updateFailCnt += 1
                    if self.updateFailCnt == 1:
                        print("Update Failed : " + self.fotaStatus)
                        print("Update Failed : 10초 후 정상 상태로 복귀")
                    if self.updateFailCnt > 10:
                        await self.updateFinishSeq()

        if self.deviceOcppStatus == ChargerStatus.Fault.name \
                and self.deviceOcppOldStatus != ChargerStatus.Fault.name \
                and self.status != NotificationStatus.Fault.name \
                and self.status != ChargerStatus.Charging.name \
                and self.status != ChargerStatus.Finish.name:
            self.setStatNotificationMessage(NotificationStatus.Fault.name)
            self.setStatus(ChargerStatus.Fault.name)

        if self.heartbeatInterval is not None:
            if self.heartbeatCnt >= self.heartbeatInterval:
                # 서버에서 heartbeat 와 같이 statusNotification 을 같이 보내 달라는 요구가 있음

                heartbeat_req_payload = {}
                heartbeat_call = Call(Action.Heartbeat.name, heartbeat_req_payload)

                if self.status != ChargerStatus.Tagging.name and self.status != ChargerStatus.Authorize.name:
                    self.setStatNotificationMessage(self.deviceOcppStatus)
                print("self.deviceOcppStatus : " + self.deviceOcppStatus)

                await self.ws.requestAction(heartbeat_call.message)

                self.heartbeatCnt = 0
            self.heartbeatCnt += 1

        if self.statNotificationFlag is False and self.status is not None and self.status != ChargerStatus.Init.name:
            print("statusNotification")

            status, errorCode, vendorErrorCode = self.getStatusAndErrorCode()

            statusNotification_req_payload = StatusNotificationReqPayload(
                connectorId=self.connectorId,
                errorCode=errorCode,
                status=status,
                vendorId=self.vendorName,
                timestamp=str(datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")),
                vendorErrorCode=vendorErrorCode,
            )

            statusNotification_call = Call(Action.StatusNotification.name, statusNotification_req_payload.json)

            await self.ws.requestAction(statusNotification_call.message)
            self.statNotificationFlag = True

        if self.status != ChargerStatus.Ready.name and \
                self.status != ChargerStatus.Init.name and \
                self.chargingStatus != ChargerActiveStatus.MeterValue.name and \
                self.status != ChargerStatus.Fault.name and \
                self.status != ChargerStatus.Comm_fault.name and self.status != ChargerStatus.Update.name:
            self.flowCnt += 1
            if self.flowCnt > self.flowInterval:
                print(self.flowInterval, "초 동안 응답이 없어 Ready 상태로 복귀 합니다.")
                self.flowCnt = 0
                self.setStatus(ChargerStatus.InitializeData.name)

                writeValue = self.modbusStatusWriteValue["authorize_fail"]
                if self.chargerMode == "CB":
                    writeValue += self.modbusStatusWriteValue["mode_cb"]
                if self.chargerMode == "Local":
                    writeValue += self.modbusStatusWriteValue["mode_local"]

                if self.data["status"][3] == "1":
                    self.writeMcuData(
                        1,
                        self.modbusWriteAddr["status"],
                        [writeValue]
                    )

    async def testMain(self):

        bootNotification_req_payload = BootNotificationReqPayload(
            chargePointModel="Model 3",
            chargePointVendor="CROCUS",
        )
        bootNotification_call = Call(Action.BootNotification.name, bootNotification_req_payload.json)
        await self.ws.requestAction(bootNotification_call.message)

        statusNotification_req_payload = StatusNotificationReqPayload(
            connectorId=1,
            errorCode="",
            status="Available",
            vendorId="CROCUS",
            timestamp=str(datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")),
            vendorErrorCode="vendorErrorCode",
        )
        statusNotification_call = Call(Action.StatusNotification.name, statusNotification_req_payload.json)
        await self.ws.requestAction(statusNotification_call.message)

    async def main(self):
        if DEBUG_LOGGING:
            if not (os.path.isdir("./Log")):
                os.makedirs(os.path.join("./Log"))
            now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            dateTimeString = str("%s" % now.date().strftime("%Y_%m_%d"))

            if not (os.path.isfile("./Log/MCU_" + dateTimeString + ".txt")):
                if self.fileHandler_MCU is not None:
                    yesterday = date.today() - timedelta(1)

                    tdt_yesterday = yesterday.strftime('%Y_%m_%d')
                    fileName_SubString = self.fileHandler_MCU.baseFilename[-14:-4]
                    if fileName_SubString == tdt_yesterday:
                        try:
                            self.logger_MCU.removeHandler(self.fileHandler_MCU)
                            self.fileHandler_MCU.close()
                            self.fileHandler_MCU = None
                        except Exception as e:
                            print(e)
            if self.fileHandler_MCU is None:
                try:
                    self.fileHandler_MCU = logging.handlers.RotatingFileHandler(filename="./Log/MCU_" +
                                                                                         dateTimeString + ".txt",
                                                                                maxBytes=self.file_max_bytes,
                                                                                backupCount=10)
                    self.fileHandler_MCU.setFormatter(self.formatter)
                    self.logger_MCU.addHandler(self.fileHandler_MCU)
                    self.logger_MCU.setLevel(logging.DEBUG)
                except Exception as e:
                    print(e)

        while True:
            try:
                await self.start()
                # await self.testStart()
                print("MCU Class Running")

            except Exception as e:
                print(e)
            finally:
                await asyncio.sleep(self.sleepInterval)
