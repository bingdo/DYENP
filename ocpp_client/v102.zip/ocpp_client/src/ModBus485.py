import serial


class ModBus485:

    def __init__(self, commId, baudRate):
        self.hSerial = None
        self.port = commId
        self.baudRate = baudRate

    def Connect(self, port_no, baud):
        try:
            self.hSerial = serial.Serial(
                port=port_no,
                baudrate=baud,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=2.0,
                inter_byte_timeout=0.1
            )
            return self.hSerial
        except (OSError, serial.SerialException):
            print('Port Not Found Error')
            self.hSerial = None

    def Disconnect(self):
        print(self.hSerial)
        # print(serial.serialwin32.Serial)
        # if type(self.hSerial) == serial.serialwin32.Serial:
        self.hSerial.close()

    def isConnection(self):
        try:
            if self.hSerial is None or self.hSerial == 0:
                self.hSerial = self.Connect(self.port, self.baudRate)
        except Exception as e:
            raise e

    def SendData(self, dataPacket):
        try:
            # self.hSerial.write(bytearray(datapacket))
            self.hSerial.write(dataPacket)
        except Exception as e:
            if self.hSerial != 0 or self.hSerial is not None:
                print('DataWrite Error')
            raise e

    def ReceiveData(self):
        try:
            dataarray = []
            dataArray = self.hSerial.read(size=1000)
            return dataArray
        except Exception as e:
            if self.hSerial != 0 or self.hSerial is not None:
                print('DataRead Error')
            raise e

    def findHeaderPosition_485(self, rBuff, header):
        length = len(rBuff) - 4
        position = []
        for i in range(length):
            if rBuff[i] == header[0] and rBuff[i + 1] == header[1]:
                position.append(i)
                # break
        return position

    def GetCRC(self, dataArr):
        crc16 = 65535
        length = len(dataArr)
        j = 0
        while length > 0:
            crc16 ^= int(dataArr[j])
            j += 1
            length -= 1
            for i in range(8):
                flag = crc16 & 1
                crc16 >>= 1
                if flag != 0:
                    crc16 ^= 40961

        return crc16

    def responseValidate(self, header, array):
        try:
            length = len(array)
            if length >= 5:
                # self.validate(array)
                hOffset = self.findHeaderPosition_485(array, header)
                # commid(1), FuncCode(1), startAddr(2), dataSize(2), checksum(2)
                Plength = len(hOffset)
                # command = int(array[1], 10)
                command = array[1]
                rBuff = []
                if Plength > 0:
                    for i in hOffset:
                        packetLength = 0
                        addPacketLength = 0
                        if command == 4:
                            packetLength = array[i + 2]
                            addPacketLength = 5
                        if command == 16:
                            packetLength = 8
                        if length >= (i + packetLength + addPacketLength):
                            rBuff = array[i: i + packetLength + addPacketLength]

                            crcUB = rBuff[-2]
                            crcLB = rBuff[-1]

                            dataCRC = self.GetCRC(rBuff[:-2])

                            dataCRC_LB = (dataCRC >> 8) & 0x00ff
                            dataCRC_UB = dataCRC & 0x00ff

                            # print("hOffset : %d" % i)
                            # print("dataCRC : %04x" % dataCRC)
                            # print("crcUB : %02x" % crcUB)
                            # print("crcLB : %02x" % crcLB)

                            if dataCRC_UB == crcUB and dataCRC_LB == crcLB:
                                # print("MCU CRC OK")
                                rBuff = array[:]
                                break
                            else:
                                print("MCU CRC Fail")
                                rBuff = []
                        else:
                            print("packetLength : %d" % packetLength)
                            rBuff = []
                return rBuff
        except Exception as e:
            print("responseValidate")
            print(e)
            raise e

    def makeModbusMessage(self, deviceId, code, startAddr, dataCount, dataList):
        functionCodeHex = format(code, '02x').zfill(4)
        addrHex = format(startAddr, '04x').zfill(4)
        dataCountHex = format(dataCount, '04x').zfill(4)

        functionCode = int(functionCodeHex, 16)
        upperStartAddr = int(addrHex[:2], 16)
        lowerStartAddr = int(addrHex[2:], 16)
        upperDataCount = int(dataCountHex[:2], 16)
        lowerDataCount = int(dataCountHex[2:], 16)

        # integerFunctionCode = int(functionCode, 10)

        writeData = [
            deviceId,
            functionCode,
            upperStartAddr,
            lowerStartAddr,
            upperDataCount,
            lowerDataCount
        ]

        if functionCode == 16:
            writeData.append(dataCount)
            for data in dataList:
                dataHex = format(data, '04x').zfill(4)
                upperData = int(dataHex[:2], 16)
                lowerData = int(dataHex[2:], 16)
                writeData.append(upperData)
                writeData.append(lowerData)
            # elif dataCount == 2:
            #     sendValue = format(data, "08x")

        crcData = self.GetCRC(writeData)
        upperByte = (crcData >> 8) & 0xff
        lowerByte = crcData & 0xff
        writeData.append(lowerByte)
        writeData.append(upperByte)

        return writeData

    def ReadMCU(self, deviceId, startAddr, dataCount):
        try:
            functionCode = 4
            self.isConnection()
            data = self.makeModbusMessage(deviceId, functionCode, startAddr, dataCount, [])
            header = data[:2]
            self.SendData(data)
            dataArray = self.ReceiveData()

            print("ReadMCU Function")
            print("Send Data Array : ", data)

            a = []
            for i in dataArray:
                a.append(i)

            print("receiveData : ", a)

            if dataArray != b'':
                res = self.responseValidate(header, dataArray)
                # return res[3:-2]
                return a[3:-2]
            return None
        except Exception as e:
            print(e)
            raise e

    def WriteMCU(self, deviceId, addr, dataCount, data):
        self.isConnection()
        # deviceId(1), FunctionCode(1), startAddr(2), dataCount(2), byteCount(1), value(2*n), CRC(2)
        # 0xC8 = 200(modbus map 상의 Status 주소)
        # writeData = [0x01, 0x10, 0x00, 0xC8, 0x00, 0x01, 0x02]
        functionCode = 16

        data = self.makeModbusMessage(deviceId, functionCode, addr, dataCount, data)

        header = data[:2]
        self.SendData(data)
        dataArray = self.ReceiveData()

        print("WriteMCU Function")
        print("Write Data Array : ", data)
        a = []
        for i in dataArray:
            a.append(i)

        print("receiveData : ", a)

        if dataArray != b'':
            res = self.responseValidate(header, dataArray)
            return res[3:-2]
        return None

    # def WriteMCUStatus(self, deviceId, data):
    #     self.isConnection()
    #     # deviceId(1), FunctionCode(1), startAddr(2), dataCount(2), byteCount(1), value(2*n), CRC(2)
    #     # 0xC8 = 200(modbus map 상의 Status 주소)
    #     # writeData = [0x01, 0x10, 0x00, 0xC8, 0x00, 0x01, 0x02]
    #     functionCode = 16
    #     addr = 200
    #
    #     data = self.makeModbusMessage(deviceId, functionCode, addr, 1, data)
    #
    #     header = data[:2]
    #     self.SendData(data)
    #     dataArray = self.ReceiveData()
    #
    #     if dataArray != b'':
    #         res = self.responseValidate(header, dataArray)
    #         return res[3:-2]
    #     return None
    #
    # def WriteMCUChargerType(self, deviceId, data):
    #     # deviceId(1), FunctionCode(1), startAddr(2), dataCount(2), byteCount(1), value(2*n), CRC(2)
    #     # 0xC9 = 200(modbus map 상의 Status 주소)
    #     # writeData = [0x01, 0x10, 0x00, 0xC9, 0x00, 0x01, 0x02]
    #     self.isConnection()
    #     functionCode = 16
    #     addr = 201
    #
    #     data = self.makeModbusMessage(deviceId, functionCode, addr, 1, [data])
    #
    #     header = data[:2]
    #     self.SendData(data)
    #     dataArray = self.ReceiveData()
    #
    #     if dataArray != b'':
    #         res = self.responseValidate(header, dataArray)
    #         return res[3:-2]
    #     return None
    #
    # def WriteMCURunCount(self, deviceId, data):
    #     # deviceId(1), FunctionCode(1), startAddr(2), dataCount(2), byteCount(1), value(2*n), CRC(2)
    #     # CA = 202(modbus map 상의 runCount 주소)
    #     # writeData = [0x01, 0x10, 0x00, 0xCA, 0x00, 0x01, 0x02]
    #
    #     self.isConnection()
    #     functionCode = 16
    #     addr = 202
    #
    #     data = self.makeModbusMessage(deviceId, functionCode, addr, 1, [data])
    #
    #     header = data[:2]
    #     self.SendData(data)
    #     dataArray = self.ReceiveData()
    #
    #     if dataArray != b'':
    #         res = self.responseValidate(header, dataArray)
    #         return res[3:-2]
    #     return None
    #
    # def WriteMCUFaultCode(self, deviceId, data):
    #     self.isConnection()
    #     functionCode = 16
    #     addr = 203
    #
    #     data = self.makeModbusMessage(deviceId, functionCode, addr, 1, [data])
    #
    #     header = data[:2]
    #     self.SendData(data)
    #     dataArray = self.ReceiveData()
    #
    #     if dataArray != b'':
    #         res = self.responseValidate(header, dataArray)
    #         return res[3:-2]
    #     return None
    #
    # def WriteMCUAmount(self, deviceId, data):
    #     # deviceId(1), FunctionCode(1), startAddr(2), dataCount(2), byteCount(1), value(2*n), CRC(2)
    #     # 0xCC = 204(modbus map 상의 Amount 주소)
    #     # 충전요금의 대한 정보는 4 Byte 로 byteCount 는 4
    #     # writeData = [0x01, 0x10, 0x00, 0xCC, 0x00, 0x01, 0x04]
    #     self.isConnection()
    #     functionCode = 16
    #     addr = 204
    #
    #     data = self.makeModbusMessage(deviceId, functionCode, addr, 2, [data])
    #
    #     header = data[:2]
    #     self.SendData(data)
    #     dataArray = self.ReceiveData()
    #
    #     if dataArray != b'':
    #         res = self.responseValidate(header, dataArray)
    #         return res[3:-2]
    #     return None
    #
    # def WriteMCUVersion(self, deviceId, data):
    #
    #     self.isConnection()
    #     functionCode = 16
    #     addr = 210
    #
    #     data = self.makeModbusMessage(deviceId, functionCode, addr, 1, [data])
    #
    #     header = data[:2]
    #     self.SendData(data)
    #     dataArray = self.ReceiveData()
    #
    #     if dataArray != b'':
    #         res = self.responseValidate(header, dataArray)
    #         return res[3:-2]
    #     return None
    #
    # def WriteMCUConfig(self, deviceId, data):
    #
    #     self.isConnection()
    #     functionCode = 16
    #     addr = 211
    #
    #     data = self.makeModbusMessage(deviceId, functionCode, addr, 1, [data])
    #
    #     header = data[:2]
    #     self.SendData(data)
    #     dataArray = self.ReceiveData()
    #
    #     if dataArray != b'':
    #         res = self.responseValidate(header, dataArray)
    #         return res[3:-2]
    #     return None
