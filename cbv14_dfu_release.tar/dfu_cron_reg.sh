#!/usr/bin/bash
RUN_DFU_FILE="run_dfu_log"

cd /etc/cron.daily/
#if [ ! -e $RUN_DFU_FILE ]; then
#	sudo cp -f /home/cb/$RUN_DFU_FILE /etc/cron.daily/
#fi
sudo cp -f /home/cb/$RUN_DFU_FILE /etc/cron.daily/
