#!/usr/bin/bash
RUN_DFU_FILE="run_update"

cd /etc/cron.daily/
sudo cp -f /usr/local/apps/fw_upgrade_utils/$RUN_DFU_FILE /etc/cron.daily/
